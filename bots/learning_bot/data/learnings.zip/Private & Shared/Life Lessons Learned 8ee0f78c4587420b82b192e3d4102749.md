# Life Lessons Learned

This phase of the side is like a personal Blog, I share what techniques and methods work in my Life, and which I apply actively. This phase is here to help you with the things I learned.

[Life Lessons](Life%20Lessons%20Learned%208ee0f78c4587420b82b192e3d4102749/Life%20Lessons%205b7da8fcf97f4f4e878cab456d54ab0f.csv)