# Barefood running

Created: July 20, 2024 1:29 PM
Kategorie: Health
Status: notes in review
Inspiration: Vibrabarefood

## What is it ?

⇒ it sticks to my value nature

⇒ Why do we need shoes ?

⇒ because of protection mainly

⇒ our shoes try to support our foot, but I think the natural way is more healthy for our food and joints

⇒ I try to walk in barefood shoes, that I get the protection arround my foot, butmy foot can fit to his natural shape and gets stronger over time

⇒ It prevents me from injury, is more protective to my knees and anckles 

## Explanation of that shit

- it helps to prevent foot injury
- running with the shoes people by nowadays disrupt the nature of our feet, hips, lower back, anckles amd knees
- barefood running is safe and more safe for your joints
- You get a more stabel and efficient movement
- normal feed reduce our natural range of motion
- imporve anckle, hip and spine mobility

## How I applied that shit

- start slow and step by step
- get enough rest in the beginning
- Read the book barefood running step by step and online videos
- Start with running slowly with knees bend
- land on your middle foot
- try to lift your foot short before it touches the ground
    - make more small steps with this technique
    - do not push them in the ground
- Relax your shoulders
- lean your body forward, it feels like you fall forward
- bend your knees a little more than you think
- foot lands underneath your body center with small and quick steps
- relax your arms and let them swing naturally
- Keep your Torso, head, neck and face upright
- relax your calves
- curve up your toes

## Step by step guide how you apply that shit

## How people benefit from that

![Untitled](Barefood%20running%20683c42176a864cfcb457390ed307f529/Untitled.png)

![Untitled](Barefood%20running%20683c42176a864cfcb457390ed307f529/Untitled%201.png)

baby steps

activate glutes

small steps feel glutes

small jumps on one leg