# Wim Hof

Created: July 20, 2024 1:29 PM
Status: notes in review

## What is it ?

- Cold exposure and breath

## Explanation of that shit

- studys and health benefits
- boost immune system
- feel your body
- boost your mitochondria
- get your body in the normal state, alkaline ⇒ away from stress
- spiritual benefits, feel your body
- mindfulness, serenity, control and energy, restfulness
- more adrenalin, anti-inflammatory, less cortisol and boost recovery
- healthy body, more endurance at sports, helps with pain

## How I applied that shit

- cold showers and breathwork
- breathwork
    - controlled hyperventilation, breath through belly breast in head ⇒ release exhale
    - inhale more than exhale ⇒ blood has more oxygin
    - less co2 in lungs ⇒ can hold breath longer
    - breath until feal little drowsiness, dizzy, or feel tingling ⇒ then breath deep and hold breath
- Cold exposure
    - temprature decrese  ⇒ activate brown fat ⇒ burns white fat ⇒ produces heat

## Step by step guide how you apply that shit

## How people benefit from that