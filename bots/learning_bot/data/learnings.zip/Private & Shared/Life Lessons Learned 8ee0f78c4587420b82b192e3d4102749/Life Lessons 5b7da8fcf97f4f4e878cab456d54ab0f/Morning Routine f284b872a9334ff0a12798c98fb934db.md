# Morning Routine

Created: July 20, 2024 1:29 PM
Status: Notes in Progress

## What is it ?

- Movement (QIgong, Yoga, stretching, HIIT, exercise)
- Silence( meditation, Qigong, journaling)
- Learning(book, online course, youtube, podcast)

## Explanation of that shit

- go outside every morning

## How I applied that shit

- Salt water ⇒ lauwarm
- make bed
- do something very important after wakeup
- FLugmodus erst raus nach der Morgenroutine

## Step by step guide how you apply that shit

## How people benefit from that

Morning

1. Have a mesningful Mission, do what Servus your Mission, who You Are and what You stand for
Simple effektive consistent
Feel grounded centered for the day ready
Affirmation
2. Master your Night Evening Routine feeling rest, prepare Morning Routine Next day, Less Stress, Rest , set clear goals , GiveDirectly You Clarity
Share 3 things grateful, Calm and relax Evening Routine
Set clear Intention how to Show up
1 thing You do at Night to Master your Morning
3. Sett your Intention
When i Wake up i do x and y, set Daily Intention, be Kind, Show up happy, Full Energy,
Morning
School of greatness Daily Motivation, workout, make bed, clean Space Environment, Intention dont Check phone, Wakeup thankyou i am enough, gratitude,
Align thoughts and actions,
Small Daily actions Set the Intentions Based on Life Vision
Bring prepared,
4. simple and consistent
Aleways Go back to the fundamental, hold yourself Accountable, Show up keep it simple, have acountability, make Healthy Habits simple, when You do to much You geht out of Balance, when wake up and Check phone your Life is More Stressed
5. practice greatness mindset
To do what 5% of tje Worms have You Need to do what 95% of the people Font do, ich hab 1 Person gefunden in meinem Leben die das so intensiv macht wie ich, eine die einen anderen weg so geht, du eine die noch einen anderen weg aber mit der gleichen Intensität geht, deswegen weis ich das es klappen wird, weil ich niemanden finde in meinem Alter der das gleiche macht.
What do I Need to let Go to achieve it ?
Phone, Porn, Funk Food, processed Food, no Sport, beleidigt sein, Compare,
There is Always More to learn, when You dont use it You lose it
Mentors Coaches usw You learn From
6. Enemy of greatness
Self Doubt, i am Not enough, Not Talenten enough, fixed vs growth mindset

plan next week fr st

learned last week

top priority next week

combine todos 

Intentions of the day

Have fun as an indicator of how you live your day

Be Super spontanious, and Change to feel satisfied

When doing a trip, follow your intuition 

Wake up without alarm ⇒ meditate ⇒ weight ⇒ Iron +Vitamin C/D 

Evening routine

-