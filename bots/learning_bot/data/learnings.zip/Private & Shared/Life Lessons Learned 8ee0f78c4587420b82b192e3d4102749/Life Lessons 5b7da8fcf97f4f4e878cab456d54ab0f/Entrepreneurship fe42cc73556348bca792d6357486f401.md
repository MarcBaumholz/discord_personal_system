# Entrepreneurship

Created: July 20, 2024 1:29 PM

## What is it ?

## Explanation of that shit

## Strategies

- wichtig Transparenz => lets schwätz
- weekly scrum or 2 Weeks
- OKR process
- Comapny Culture ( ps3, tischkicker, teamevents, cooking, merch, playlist, I wish I like, teamretreats, Mission VIssion, fundamental values)
- Make a list of 25 People who you need to connect to scale in your industry
- Stack different skills never seen before