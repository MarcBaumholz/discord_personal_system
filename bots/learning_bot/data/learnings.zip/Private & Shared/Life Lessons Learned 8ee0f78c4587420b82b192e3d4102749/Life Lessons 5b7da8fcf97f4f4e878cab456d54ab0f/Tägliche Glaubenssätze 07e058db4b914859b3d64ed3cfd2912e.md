# Tägliche Glaubenssätze

Created: July 20, 2024 1:29 PM

1. Allow Whitespace in your day, when you do not allow Whitespace will come when you do not want it
    1. protect it => it is like a Stress buffer
2. When I force something to strong I do not get it, think more, it is better to go 2 steps in the right direction than 100 in the wrong direction
3. Be useful today, those who not try, will be sad in the end
4. listen deeply to the people arround you
5. you need to first control your own life, before you help others to control theirs
6. contribute more than you consume
7. little by little becomes a lot
8. In the end it matters how you spend your time
9. Knowledge is like food, you need to digest it, apply it that it helps you and works
10. The best things in your life werent planned
11. Be naive enough to think that you can make a difference
12. Your Values are often a result of past pain