# The concept of Non Time

Created: July 20, 2024 1:29 PM

- you need to also plan time for your freetime and relaxation
- because the body will take it anyway. When you dont plan it, the body will take it when you dont want it
-