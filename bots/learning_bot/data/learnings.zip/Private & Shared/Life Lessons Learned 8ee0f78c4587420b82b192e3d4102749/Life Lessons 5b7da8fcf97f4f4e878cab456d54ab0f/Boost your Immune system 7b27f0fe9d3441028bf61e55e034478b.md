# Boost your Immune system

Created: July 20, 2024 1:29 PM
Status: Notes in Progress

## What is it ?

- I explain how I get less ill and If I get ill what do i do to get fit again

## Explanation of that shit

- I use my energy routine to get more vitality
- Fasting, drink much, natural sunlight, wim hof breath, less stress, meditate, Qigong, cold exposure
- eat less sugar, best to eat no sugar, same with nikotin, alkohol and coffeine
- take care of mold in your environment
- daily sunlight and fresh air
- Daily habit of box breathing to relax the body
- stay hydrated, still water with good ingridients
    - when you are thirsty, it is too late
    - drink after wakeup and during the day arround 3L
- Optimize your sleep
- do regular exercise, use your muscles daily
- Diet and lifestyle

## Step by step guide how you apply that shit

- 3 Step Formular
    1. Nutrition 
        1. Eat healthy and natural foods, many vegtables
    2. Drinking
        1. Drink mineral rich Water and Tea(Chamomile or Lime blossom tea) 
        2. Lemon, garlic, Ginger, honey
    3. Breath
        1. Do a kind of relxing breathwork and Qigong outside
- What I do when I get sick
    1. Getting enough restful sleep at least 8h 
    2. Fasting 12 to 16h 
    3. Drink a healthy green smoothie with lots of minerals 
    4. Drink a lot of water 
    5. Do the energy medizine routine from Donna Eden
        1. [https://www.youtube.com/watch?v=NFk_77qewBc](https://www.youtube.com/watch?v=NFk_77qewBc)
    6. Take a shower, optional ⇒ hot cold shower(10sec warm, 20sec cold)
    7. Do Qigong ⇒ there are lots of benefitial movements ⇒ Yoga is also possible
        1. [https://www.youtube.com/watch?v=UpN3AcXLSSk](https://www.youtube.com/watch?v=UpN3AcXLSSk)
    8. Get sunlight in the morning
    9. Use my mind ⇒ Meditation 
    10. Wim Hof Breathwork, I swear to that, this gives me energy
        1. 4 periods of 30 long and deep inhales + breath holding
        2. [https://www.youtube.com/watch?v=BckqffhrF1M&t=243s](https://www.youtube.com/watch?v=BckqffhrF1M&t=243s)
    11. Lemon, garlic, Ginger, honey

## What is my Approach

- when I do not make time for exercise and proper Nutrition, I need to make time for illness
- I keep myself healthy through
    - daily sunlight in the morning and during the day
    - a healthy breakfast to start in the day with many minerals
    - I drink at least 3 liters a day and this consistently, I have always water arround me with high calcium and magnesium
    - I get enough fresh air during the day
    - I do some stretching and little sport exercise 3-5 times during the day in my short breaks
    - I take microbreaks during the day for some breathwork or meditation
    - I balance my life and do not get too stressed about work, I take time for myself

Brainstorming 

Reduce chronic and bad stress ⇒ stress number one indicator of illness

do box breath when something triggers you 

no sugar, no nicogitne, 

less caffeine, less alcohol

breathwork as a daily practice

breath outside, go outside, box breath

drink enough mineral rich water 

wakeup without alarm 8h 

get 15-20min unprotected sunlight  daily 

stretch daily

shaolin qiging taiji inner work 

walk 7-15k steps a day 

body

emotional

who makes you feel great ?

friends, handball, gym,meditate, learing, start, loved ones ( hugs, cuddl and hand holds) 

What makes you feel happy ?

sport, talk with friends, talk about passion, read, yoga, sunsets, relax, sauna, whirlpool, cinema,