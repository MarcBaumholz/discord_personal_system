# Curiosity List

Created: July 20, 2024 1:29 PM

## What is it ?

- based on the research of Steven Kotler a Flow expert, to find your Purpose in life, you start with finding things you are curious about and make a list of 25 Things ⇒ you collect 5-6 themes out of these 25 curiosities and these are your passions ⇒ then you search for big problems you would like to be solved and you find a way to use your curiosities and passions to solve a purpose

## Explanation of that shit

## How I applied that shit

1**.** **Neuroscience**

Definition:

How do I live it:

**2. Sport, erxercise strength training**

Definition:

How do I live it:

**3. AI and machine learning, digitize brain, Datascience**

Definition:

How do I live it:

**4. Newest technology, AR,VR, BCI, Robots**

Definition:

How do I live it:

**5. Magic tricks**

Definition:

How do I live it:

**6. Monk, Asian Culture Buddism**

Definition:

How do I live it:

**7. Sexual Transmutation & Tantra**

Definition:

How do I live it:

**8. Startups, Entrepreneurship**

Definition:

How do I live it:

**9. Outer Space, Astronomy**

Definition:

How do I live it:

**10. Learning and Flow, productivity**

Definition:

How do I live it:

**11. Biohacking**

Definition:

Changing internal and external influences in order to gain control over one's own nature. 

How do I live it:

**12. Dream states, altered states**

Definition:

How do I live it:

**13. Psychology**

Definition:

How do I live it:

**14. Coaching, helping, giving**

Definition:

How do I live it:

**15. Personal Growth/Transformation**

Definition:

How do I live it:

**16. Networking, communication, Relationships**

Definition:

How do I live it:

**17. Meditation, Spirituality, Mindfullness**

Definition:

How do I live it:

**18. Self Mastery**

Definition:

How do I live it:

**19. Management**

Definition:

How do I live it:

**20. Movies & Music**

Definition:

How do I live it:

**21. science of happiness**

Definition:

How do I live it:

**22. Visit new places**

Definition:

How do I live it:

**23. Routines**

Definition:

How do I live it:

**24. Energy Work**

Definition:

How do I live it:

**25. Sustainability**

Definition:

How do I live it:

## Step by step guide how you apply that shit

## How people benefit from that