# Interviews

Created: July 20, 2024 1:29 PM

My Topics for start ⇒ Entrepreneurship, Productivity, Startups, Routines, Culture, Mindset, Life 

1. Look for people you like to know and fit in your category
2. start by talking to them first and define a clear goal and output of this
3. start with a very personal introduction of them ⇒ why you have choosen him/her 
4. have first personal related questions and later more about business
5. express your passion and listen to from new questions
    1. talk about topics instead of prepare questions 
6. have a good sound 
7. take notes during the process
8. conclusion words summ it up and bring your key learnings ⇒ further connection 
9. have a jingle in the beginning as intro and in the end as outro 
10. Hook at the beginning the most interesting and valuable part 
11. start with 6-7 pre recorded episodes