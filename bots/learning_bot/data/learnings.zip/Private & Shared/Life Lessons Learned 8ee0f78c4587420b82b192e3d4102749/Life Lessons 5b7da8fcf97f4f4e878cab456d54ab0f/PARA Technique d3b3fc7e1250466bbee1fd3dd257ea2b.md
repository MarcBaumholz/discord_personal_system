# PARA Technique

Created: July 20, 2024 1:29 PM
Status: Notes in Progress
Inspiration: Tiago Forte

## What is it ?

How to take notes, that your brain learn the best

PARA

PROJECTS ⇒ actionable things to turn into projects to work on

AREA ⇒ Areas where you can apply the knowledge and how

first 2 very actionable

RESSOURCES ⇒ basic understanding about the things, things you cant apply but want to know

ARCHIVE ⇒ in archieve you put all the things you that are not that important, but still as important that you cannot miss them 

It is important to organise your work action oriented

CODE

COLLECT ⇒ the information

ORGANISE ⇒ with PARA method organise your information

DESTILL ⇒ review it and look for a way to apply it

EXPRESS ⇒ share it and teach it to others

## Explanation of that shit

## How I applied that shit

## Step by step guide how you apply that shit

## How people benefit from that

Project ⇒ Weekly check

future, upcoming, active, completed and archived projects 

timeline, specific purpose and ending

action oriented

short termed ⇒ track 

keep 10-15 active projects

never get stuck in projects ⇒  switch

False projects

dreams ⇒ no deadline

Hobbies ⇒ no specific goal

Areas of responsibility ⇒ ongoing things support and develop over time 

megaprojects ⇒ a collection of sub projects too big (write a book) 

Areas ⇒  Monthly check

- tole of responisbility
- ongoing maintanance
- never complete
- no goal you reach ( relationship, health, dreams, wishes=

![Untitled](PARA%20Technique%20d3b3fc7e1250466bbee1fd3dd257ea2b/Untitled.png)

Ressources ⇒ review as neded

- any topic ongoing interest
- inspiration for future

Archive ⇒ storage

- inactive items
- when something is compeleted, put them in archive

start week

calender, email, todo list , task manager, desktop

![Untitled](PARA%20Technique%20d3b3fc7e1250466bbee1fd3dd257ea2b/Untitled%201.png)

highlight which topics move forward this week

durioing week

end week