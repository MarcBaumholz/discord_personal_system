# The Value Thing

Created: July 20, 2024 1:29 PM

The value thing

Values often come from past pain

Transperency

- nowadays everybody is hiding things because of a fear, that is so anoying, when we are more transperent we can create more things together

Curiosity

- School and parents, good grades, you need to fit in, curiosity is not about how to fit in, it is about you what are your interests

Share

- we share to less, because we are afraid, share what you know, what you learn, people think other people steal, but sharing is caring. Nobody can do it like you