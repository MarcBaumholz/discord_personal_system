# Marcs Laws

Created: July 20, 2024 1:29 PM
Status: Notes in Progress

## What is it ?

Called Peters laws

25 Rules/Laws you establish for yourself, based on your experiences and what happened in your life

## Explanation of that shit

## How I applied that shit

## Step by step guide how you apply that shit

## How people benefit from that