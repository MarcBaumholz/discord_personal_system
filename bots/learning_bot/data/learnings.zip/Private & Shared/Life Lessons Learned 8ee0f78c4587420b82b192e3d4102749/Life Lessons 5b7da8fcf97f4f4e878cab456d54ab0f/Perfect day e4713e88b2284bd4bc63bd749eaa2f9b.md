# Perfect day

Created: July 20, 2024 1:29 PM

6-7 Morning Routine 1h

Silence, Affirmation, Active, Learning, Journal, Natural light

1. Meditation, breathwork,
2. Intentions about the day, journal
3. HIIT Workout, Yoga, Qigong, Taiqi, stretching, energy medizin
4. Book, Podcast, online Course

7-12 Beast Mode 5h

Deep work, eat the frog first, no distractions

1. start with easy task to get into flow, review yesterday
2. go for the hard task of the day
3. do enough short breaks (Air, water, movement)
4. Use pomodoro or 60 to 90min cycles with Deep Work

12-13 Power Mode

1. Sport oder Qigong/Yoga 20min
    1. power out the body
    2. Get out of the head

13-14 Healthy Lunch

Eat Lunch Healthy

14-14:30 Work Mode

start with reactive tasks

get back into working mood, emails, easy tasks

14:30 1730 Second beast mode session or management work

1. Creative Deep work, Not that much concentraition 
2. finish the tasks
3. meetings

1730 17:45

1. plan next day and review current day

18-22 Free Time 

1. Socialize
2. Meet friends and Family
3. Sport
4. Go Outside

22-06 Sleep

1. have a evening routine to calm down and go to sleep
2. get 8h of restful sleep to recover
3. Journal

EWOR Workshop shedule

[https://docs.google.com/spreadsheets/d/167ddJ6-QC9Fm4cf96GeZGGHprOko8uxp/edit#gid=1151287873](https://docs.google.com/spreadsheets/d/167ddJ6-QC9Fm4cf96GeZGGHprOko8uxp/edit#gid=1151287873)