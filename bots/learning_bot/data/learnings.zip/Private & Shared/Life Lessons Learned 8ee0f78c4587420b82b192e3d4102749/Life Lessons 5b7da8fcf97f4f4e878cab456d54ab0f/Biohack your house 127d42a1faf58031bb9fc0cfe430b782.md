# Biohack your house

Created: October 22, 2024 8:45 PM

Gym room ⇒ some kettlebells, one all in one fitness workout machine, bycicle machine

infraret sauna 10 K

8 sleep 3 K

samina bed  5 K 

supplemnets 50 a month 

air purifier ⇒ 1 K

EMF block ⇒ 1K 

smart home ⇒ alexa in every room 200 €

finger print go into house ⇒ 200 €

Smart light ⇒ 200 €

Wasserfiltersystem ⇒ 200 €