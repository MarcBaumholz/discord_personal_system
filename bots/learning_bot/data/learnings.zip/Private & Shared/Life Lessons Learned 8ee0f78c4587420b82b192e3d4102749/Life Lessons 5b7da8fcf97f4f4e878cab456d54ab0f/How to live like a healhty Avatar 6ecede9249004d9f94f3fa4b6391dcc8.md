# How to live like a healhty Avatar

Created: July 20, 2024 1:29 PM

Everybody knows the series Avatar the last airbender. 
We use this Idea in our daily lives

Power of Wind => breath, hold breath, breath deeply

Power of Water => Cold exposure,  cold showers, strong immune system

Power of Fire => hot exposure Sauna, infrared therapie

Power of Earth => ground yourself, walk barefood, eat healthy, go in nature