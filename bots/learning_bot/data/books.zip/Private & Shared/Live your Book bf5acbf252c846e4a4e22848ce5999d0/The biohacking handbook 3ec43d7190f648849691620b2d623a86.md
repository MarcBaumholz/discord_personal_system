# The biohacking handbook

Author: Olli Sovijärvi Teemu Arina Jaako Halmetoja
Fiction?: Non-Fiction
Genres: Biohacking, Life Advice, Mindfulnes, Productivity, health
Rating: 5-Star
Notes Status: Notes In Progress
Date Finished: June 10, 2021

# 🚀 The Book in 3 Sentences

1. upgrade yourself and unleash your inner potential
2. optimize performancec, health, well being by utilizing science, techhnology and human physiology

# 🎨 Impressions

## Who Should Read It?

# ☘️ How the Book Changed Me

<aside>
💡 How my life / behaviour / thoughts / ideas have changed as a result of reading the book.

</aside>

- 

# ✍️ My Top 3 Quotes

- 

# 📒 Summary + Notes

- Sleep
    
    Ressources
    
    - get 7-8h of sleep
    - Stages 4-5 cycles of 90min each night
        - Wakefulness is beta waves
        - Meditative state, when you close your eyes alpha and theta waves, produce serotonin
        - N1 First stage 4-8hz 10min theta waves 5%
        - N2 sleep spindles 11-16hz 30min 50%
        - N3 delta waves 0-8hz deep sleep, growth hormone, muscle relaxed 40min 20%
        - REM alpha and beta brain awake, body asleep, dream state, regenerate brain cells, improve memory 25%
    - Blue light dirrectly affects the production of the sleep hormone melatonin
    - Take no caffeine after 2 pm, take no alkohol in the evening, it disrupts rem sleep
    - Avoid Bacon, cheese, chocolate, eggplant, potato, sauerkraut, sausage, spinach, tomato and wine in the evening ⇒ increse production of noradrenaline which keeps you awake
    
    Actions
    
    - Prepare bedroom
        - Darkening the Bedroom ⇒ use blackout curtains, darkening all LED’s, switch lamps to red or orange light
        - bed Quality
            - mattress made of organic cotton, wool, hemp or natural rubber
            - sheet material(organic cotton, silk, leather)
            - Sleep without clothes and practice cold exposure before bed
            - Pillow to support your neck and pillow between your legs when sleeping sideways
            - Sleep on right side or back ⇒ less stress on internal organs
        - electromagnetic pollution
            - use a grounding mat
            - wlan and phone outside the room
            - walking barefood or in grounding shoes during the day
            - scanning radiation in bedroom
        - Air quality
            - have house plants, golden cane palm, snake plant, devils ivy
            - Ventilate during the day and before bed
            - Air filtering
        - Temperature
            - 18-22 degrees
            - keeping windows open and ventilating the place properly
    - The right day
        - blue light after wake up for alertness and circadian rythm
        - daily 15min walk in sunlight
        - workstation next to a window
        - 20 to 30min daily exercise
        - acupuncture, massage, sauna, yoga, stretching, relaxing bath(with magnesium)
        - going to bed and waking up at the same time every day
        - empty your mind before going to bed, write things down, write a to do list, meditate, gratitude journal or positive affirmations
        - block blue light in the evening
        - eat at least 2-4h before going to bed
- Nutrition
- Exercise
- Work
- Mind