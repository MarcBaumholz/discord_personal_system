# The leader with no title

Fiction?: Non-Fiction
Notes Status: Notes in review

# 🚀 The Book in 3 Sentences

1. 

# 🎨 Impressions

## How I Discovered It

## Who Should Read It?

# ☘️ How the Book Changed Me

<aside>
💡 How my life / behaviour / thoughts / ideas have changed as a result of reading the book.

</aside>

- Everybody needs someone who inspires them and brings them to a point where they make the best out of their life
- Everybody needs to take responsibility over his own life

# ✍️ My Top 3 Quotes

- you can also shake the world in a gentle way ~ghandi

# 📒 Summary + Notes

- 1 & 2Leadership and success are your birthtights
    
    Ressources
    
    ⇒ titles don't interest me, giving my best at work is what matters
    
    ⇒ The more demanding the conditions, the more fabulous the opportunities.
    
    ⇒ sometimes we have to get off track a bit before we can clearly see how to get back on track.
    
    ⇒ Be true to yourself and that will follow as the night follows the day, that you cannot be false to another.
    
    Actions
    
    ⇒ be open to new things
    
    ⇒ i decide not to let my life be determined by labels
    
    ⇒ we all need to see ourselves as leaders in the position and place we have been placed.
    
    ⇒ Inspire others and pass on what you have learned
    
- 3
    
    Ressourcecs
    
    ⇒ sei zufrieden, aber geb dich nicht zufrieden
    
    ⇒ all die materiellen Dinge zählen nicht, am ende zählt nur ob du dedn mut aufgebracht hast deine gabe in die Welt zu tragen 
    
    ⇒ unverwiirklichtes potenzial verwandelt sich in Schmerz
    
    ⇒ Erfolg entsteht durch tägliche umsetzung kleiiner dinge, die auf lange sicht zu großen heranwachsen und siich aufsummieren
    
    ⇒ Je besser du die fähigkeit besitzt entscheidungen zu treffen, umso machtvoller werden deine Entscheidungen
    
    Actions
    
    ⇒ habe die disziplin etwas zu tun weil du weist das es richtig und wichtig ist 
    
    ⇒ Wie man nichts bereut
    
    1. wenn etwas in dir sprudelt, dann drücke es aus
    2. lerne deine natürliche kraft kennen, um große dinge zu tun
    3. inspiriere leute durch den Weg den du gehst 
    4. Wage große dinge 
    5. Nehme die Chance zur großartigkeit an und verbinge dein leben nicht im Mittelmaß
    6. verwandle wiedrigkeiten in Siege, um dessen großartige chancen zu bekommen
    7. Helfe anderen menschen täglich, dein Beruf soll darauf basieren
    8. Lebe das leben, dass du dir im inneren wünschst und nicht das was die Gesellschaft dir vorschreibt
    9. nutze jeden tag um dein bestes selbst mit deiner Genialität zum vorschein zu bringen
    10. Habe keine Angst ein leader zu sein, sei es einfach und spring über deinen Schatten
    
    ⇒ Mache jeden job nach deinem besten können und engagement, dann wird auch Belohnung folgen 
    
    ⇒ Wie das Lebensende sein soll
    
    1. Voller glück und Zufriedenheit, da du weist, dass du deine begabung, deine möglichkeiten und dein potenzial völlig ausgeschöpft hast. 
    2. Du weißt, dass du deinen höchsten ansprüchen gerecht geworden bist
    3. DU hast den mut besessen dich deinen größten Ängsten zu stellen und deine Vision zu verwirklichen
    4. Du erkennst, dass du ein Mensch warst, der andere menschen aufgebaut hat, anstatt sie runterzuziehen
    5. Du warst stehts optimistisch, auch wenn du gestürzt bist, bist du stehts aufgestanden 
    6. du freust dich über die enorme bereicherung des lebens, das du den menschen verschafft hast, denen du dienen konntest
    7. Du verehrst den starken, verantwortungsbewussten, begeisternden und mitfühlenden Menschen, der du geworden bist
    8. Du warst ein erneuerer, der neue Wege gegangen ist
    9. Du hast stehts führung übernommen auch ohne titel und deine taten werden noch lange auf dieser Erde verweilen 
- 4 Sie brauchen keinen Titel und keine Position, um eine Führungspersönlichkeit zu sein
    
    Ressources
    
    - die größte freiheit ist die Entscheidungsfreiheit
    - entdecke, dass die kleinen freden des lebens die kostabrsten sind
    - Glück ist eine unerwartete Belohnung für eine intelligente Entscheidung
    - Was die Gesellschaft dednk, interessiert mich nichht, für mich ist wichtig, wie ich selbst mich sehe
    - große Menschen errichten monumente, mit den Steinen, mit denen andere sie bewerfen
    - Die 4 Natürlichen Kräfte
        - täglich sein absolut bestes zum ausdruck bringen
        - alle anderen Menschen zu inspirieren
        - leidenschaftlich positive veränderungen herbeiführen
        - Respekt, Wertschätzung und freundlichkeit zeigen
    - jede Person und jeder Job hat eine Bedeutung und jede arbeit kann mit der Strategie des Leader without a title sinnvoll werden
    - IMAGE
        - Innovation
            - Was kann ich heute verbessern ?
            - Das bemühen den heutigen Tag zu einem besseren zu machen, als den gestrigen
            - Ohne Erneuerung stirbt das leben
            - Träumen sie große Träume und fangen sie klein an, fangen sie jetzt an
        - Mastery
            - werden sie so gut, dass die Leute sie nicht ignorieren können
            - nichts weniger als mein bestes zu geben
            - Was würde die person, die in dem was ich tue, die beste der welt ist, in dieser situation tun ?
    
    Actions
    
    - mache aus deinem Job etwas, das für dich von Bedeutung ist
    - komme jeden Tag zur Arbeit mit der IIntention etwwas positives mit auf den Weg zu geben
- 4
-