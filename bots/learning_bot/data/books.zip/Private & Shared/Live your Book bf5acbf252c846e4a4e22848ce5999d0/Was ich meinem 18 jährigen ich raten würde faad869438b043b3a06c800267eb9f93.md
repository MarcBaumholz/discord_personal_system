# Was ich meinem 18 jährigen ich raten würde

Fiction?: Non-Fiction
Notes Status: Notes In Progress

# 🚀 The Book in 3 Sentences

1. 

# 🎨 Impressions

## How I Discovered It

## Who Should Read It?

# ☘️ How the Book Changed Me

<aside>
💡 How my life / behaviour / thoughts / ideas have changed as a result of reading the book.

</aside>

- 

# ✍️ My Top 3 Quotes

- 

# 📒 Summary + Notes

# 🚀 The Book in 3 Sentences

1. 

# 🎨 Impressions

## How I Discovered It

## Who Should Read It?

# ☘️ How the Book Changed Me

<aside>
💡 How my life / behaviour / thoughts / ideas have changed as a result of reading the book.

</aside>

- 

# ✍️ My Top 3 Quotes

- 

# 📒 Summary + Notes

- 1
- 2
- 3 Entwicklung deiner Persönlichkeit 126
    
    Ressources
    
    - lass dich weniger treiben, sei konzentriert und mach etwas, ohne dem Teufel eine chance zu geben
    - etwas anzufangen ohne es zuende zu bringen, ist als hättest du nie angefangen
    - Schneiden und Wachsen ⇒ schneide dinge ab die keinen Sinn ergeben und probiere neue Dinge aus um zu wachsen
    - bediene dich verschiedenen Quellen und glaube nicht alles was dir erzählt wird
    
    Actions 
    
    - probiere in jungen Jahren viele Dinge aus, entscheide selbst und geh deinen eigenen Weg, glaube an dich selber
    - baue dir ein Netzwerk auf
    - Konsumiere nicht so viel, sondern kreiere aktiv mit
- 4 Karriere und Geld
    
    Ressources
    
    - Es gibt immer menschen die rausgehen und sich holen, was sie haben wollen und es gibt den Rest
    - wenn du einmal angfängst auzugeben wird es dir immer leichter fallen
    - die allermeisten Jobs werden nicht ausgeschrieben
    - immer nur den einfachen weg zu gehen wird später im leben eine große leere lassen
    - übernimm eigenverantwortung, du allein bist für die Resultate in deinem Leben verantwortlich
    - wenn du tust was alle tun, bekommst du was alle bekommen ⇒ durchschnitt
    - Unternehmer automatisieren und Sklaieren ihr geschäft
    - Das gegenteil von Erfolg ist nicht misserfolg sondern nichts tun ⇒ es ist nur schlimm wenn du aufgibst und nichts tust
    - nicht das bessere Produkt wird verkauft, sondern das was besser vermarketet wird
    
    Actions
    
    - folge nicht dem geld, sondern deiner Leidenschaft
    - träume immer weiter und hör nicht auf ein Kind zu sein
    - mach dir klar was deine stärken sind
        - was fällt dir leicht, lernst du schnell, kannst du gut
        - für was begeisterst du dich, bist du neugierig
    - Jobinterview
        - recherchiere über die Firma und den Chef
        - warum bist du der richtige Kandidat  ?
        - Welche einwände könnten sie gegen dich haben ?
        - Was sind meine Stärken
        - Was begeistert mich an dem Unternehmen
    - Lerne dich selbst zu organisieren und für dein Selbst verantwortung zu übernehmen
    - Arbeite erfolgsorientiert
        - kreiere Kriterien an denen man deinen Erfolg messen kann und kopple dein Einkommen daran
    - Rufe an und mach dein gegenüber neugierig und vereinbare einen Termin mit dem Entscheider
    - Die bewerbungsunterlagen die ich verschicke sind 183 groß haben braune haare und kommen sehr gerne für ein Gespräch vorbei.
    - geh ins Ausland, such dir einen Mentor, lese viel, zieh frühzeitig aus, setze große Ziele, denk vom Ende aus, such dir das richtige Umfeld