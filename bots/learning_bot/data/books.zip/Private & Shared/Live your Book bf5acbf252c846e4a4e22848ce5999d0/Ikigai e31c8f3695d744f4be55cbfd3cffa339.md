# Ikigai

Fiction?: Non-Fiction
Notes Status: Notes in review
Date Finished: January 6, 2022

# 🚀 The Book in 3 Sentences

1. the japanese secret to a long and happy life

# 🎨 Impressions

## How I Discovered It

## Who Should Read It?

# ☘️ How the Book Changed Me

<aside>
💡 How my life / behaviour / thoughts / ideas have changed as a result of reading the book.

</aside>

- 

# ✍️ My Top 3 Quotes

- 

# 📒 Summary + Notes

- 1
    
    Ressources
    
    - What is your reason for being ?
    - keep your mind young by learning, interacting, playing and sharing
    - focus on the present moment and accept it
    - we are what we repeatedly do
    - the experience itself should be joyful for the sheer sake of doing it
    - technology is great if we are in control of it
    - Flow
        - what to do
        - how to do
        - how well you do it
        - where to go
        - challenging
        - skilled
        - no distractions
        - concentrate on one thing at a time
    - rituals over goals
    - happiness is the process not the goal
    - the secret is a sense of humor
    - when you have a clear purpose no one can stop you
    - the secret to a long life is DONT Worry and keep your heart young
    - eat antioxidantien rich food
        - tofu, miso, tuna, carrots,bitter lemon, cabbage, onion, soybeans, sweet potatoes, pepper jasmin tee
        - drink sanpin cha tea, white and green tea
        - eat brocoli and chard, citrus, strawberry, apricot, olive oil, grains, berries
    - it is not what happens to you that matters, it is how you react to it
    - the only moment in which you can be truly alive is the present moment
    
    Actions
    
    - eat enough vegtables, tofu, sweet potatoes and fish
    - walk for at least 20min each day
    - replace junk food with fruits
    - increase the time you spend in flow rather than allowing to get caught up in activities that offer immediate pleasure
    - when are we happiest
    - do technology fasting one day a week sat or sunday
    - read and respond to emails just twice a day, communicate that clearly
    - try the pomodoro technique
    - start work with a ritual you enjoy and end with a reward
    - practice mindfulness in every situation
    - have a habit of helping others
    - you need to slow down and relax
    - keep smiling and a child sometimes
    - practice taijiquan or Qigong for inner health