# The 5am club

Fiction?: Non-Fiction
Notes Status: Notes In Progress
Page: 164

# 🚀 The Book in 3 Sentences

1. 

# 🎨 Impressions

## How I Discovered It

## Who Should Read It?

# ☘️ How the Book Changed Me

<aside>
💡 How my life / behaviour / thoughts / ideas have changed as a result of reading the book.

</aside>

- 

# ✍️ My Top 3 Quotes

- 

# 📒 Summary + Notes

- 1
    
    Ressources
    
    - Setze ideen um, sonst sind sie nichts wert
    - entwickle deine 4 inneren Reiche
        - Mindset, Heartset, Soulset und Health set
    - Spitzenleistung basiert auf täglichen Gewohnheiten
    - Beschenke andere und du beschenkst dich selbst
    - Es gibt einen klaren unterschied zwischen beschäftigt und Produktiv sein
    - Gewinnen startet mit dem Beginnen
    - Wenn es am Anfang nicht hart wäre, dann wäre es keine richtige Veränderung
    - vollkommene Gesundheit ist wahrer Reichtum
    - Zeit ist eines der kostbaren Güter ⇒ investiere sie weise
    - du kannst dich anpassen oder du kannst die Welt verändern
    - Es beginnt alles mit der Veränderung deines Selbst
    - Veränderungen sind am Anfang mühsam, in ihrem Verlauf Chaotisch und am Ende Großartig
    
    Actions
    
    - Automatisiere möglichst viele Grundlegende Dinge
    - 60/1 Rule 90/90/1 Rule
    - Machen sie öfters Kurzurlaub
    - gestalte deinen Morgen weise und in deinem leben wird alles möglich
    - praktizieren sie Geduld und das aneigenen der richtigen Gewohnheiten
    - Nehmen sie Zeit für sich selbst
- 2
    
    Ressources
    
    - opfer öieben Unterhaltung, SIeger lieben Bildung
    - gestalte deinen Morgen und in deinem Leben wird alles möglich
    - habe den Mut deinem Herz und deiner Intuition zu folgen
    - Erinnere dich das man seine Versprechen einhält und zu seinem Wort steht
    - Schätze dinge aber sei nicht von ihnen abhängig
    - Führen bedeutet dienen
    - Herausragende Produktivität ohne gelegentliche Ruhepausen führt zu dauerhafter Erschöpfung
    - Jeder kann ein Kritiker sein, es erfordert mumm ein Ermutiger zu sein
    - Viel Gled zu haben macht einen nicht anders, es macht einen nur mehr zu dem, der man schon davor war, bevor man zu geld kam
    - je mächtiger eine Person ist, umso weniger muss sie dies zur schau stellen
    - Bessere Wahrnehmung (lernen), bessere Entscheidungen(Umsetzung), bessere Ergebnisse (Einkommen)
    - Dinge aufzuschieben, heist ebenso die eigenen Genialität aufzuschieben
    - Weltklasse zu werden ist ein Prozess kein Ereignis
    - Die Welt ist ein Spiegel, wir bekommen nicht das was wir wollen, sondern das was wir sind
    - Menschen die von Zerstreuung abhängig sind, ist der Tod der Produktivität
    - Vergleichen ist der Dieb der Freude
    
    Actions
    
    - Sag einfach ja zum Leben und setz es auch um
    - Visualisiere wer du sein willst und was du erreichen willst
    - bestimme deinen Morgen, sei wenig abhängig, habe keine Ausreden
    - Tue das was die meisten als Verrückt bezeichnen
    - Vereinfachen sie ihr leben und intensivieren sie ihre Konzentration
    - Managen sie Ihren Fokus
    - integriere Ruhe und Gelassenheit in jeden ersten Abschnitt des Tages
- 3
- 4
- 5
-