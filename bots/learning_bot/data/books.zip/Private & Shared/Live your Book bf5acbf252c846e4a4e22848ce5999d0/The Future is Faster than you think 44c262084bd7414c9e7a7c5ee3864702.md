# The Future is Faster than you think

Author: Peter H diamandis & Steven Kotler
Fiction?: Non-Fiction
Notes Status: Notes in review
Page: finish

# 🚀 The Book in 3 Sentences

1. 

# 🎨 Impressions

## How I Discovered It

## Who Should Read It?

# ☘️ How the Book Changed Me

<aside>
💡 How my life / behaviour / thoughts / ideas have changed as a result of reading the book.

</aside>

- 

# ✍️ My Top 3 Quotes

- 

# 📒 Summary + Notes

- Part One: The Power of Convergence
    
    Ressources
    
    - exponentially accelerating technology is a technology that doubles in power while dropping in price on a regular basis
    - 6 Ds
        - Digitalization
        - Deception Disruption
        - Demonetization
        - Dematerialization
        - Democratization
    - there is plenty of room at the bottom
    - the only constant is change and the pace of change is accelerating
    - saved time is one of the major benefits of technology
    - experiment, fail, pivot, fail again, pivot again and eventually get it right
    - Money
        - crowdfunding
        - free data economy ⇒ have a free product and sell the data gathered
        - smartness economy ⇒ take an existing tool and add a layer of smartness (AI)
        - closed loop ⇒ recycle stuff
    - Education
        - we have a lack of teachers ⇒ so we need to learn more self directed
    
    Actions
    
    - tap more into flow
    - Abundance digital Abundnace 360
    - zero to dangerous
- Part Two: The rebirth of everything
- Part Three: The Faster Future