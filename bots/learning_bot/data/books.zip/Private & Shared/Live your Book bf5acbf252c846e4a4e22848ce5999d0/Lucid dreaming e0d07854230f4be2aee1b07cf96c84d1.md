# Lucid dreaming

Fiction?: Non-Fiction
Notes Status: Published

# 🚀 The Book in 3 Sentences

1. 

# 🎨 Impressions

## How I Discovered It

## Who Should Read It?

# ☘️ How the Book Changed Me

<aside>
💡 How my life / behaviour / thoughts / ideas have changed as a result of reading the book.

</aside>

- 

# ✍️ My Top 3 Quotes

- 

# 📒 Summary + Notes