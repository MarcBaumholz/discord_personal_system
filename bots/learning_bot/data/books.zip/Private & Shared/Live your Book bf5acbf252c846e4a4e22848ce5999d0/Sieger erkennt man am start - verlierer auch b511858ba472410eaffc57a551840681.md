# Sieger erkennt man am start - verlierer auch

Author: Dieter Lange
Fiction?: Non-Fiction
Genres: Creativity, Life Advice, Philosophy, entrepreneur
Rating: Lifechanging
Notes Status: Notes in review
Page: Fertig
Date Finished: May 24, 2022

# 🚀 The Book in 3 Sentences

1. Entäuschung setzt Erwartung vorraus
2. Nichts und niemand kann uns glücklich machen, allenfalls unsere Erwartungen erfüllen. Demzufolge kann uns aber auch nichts und niemand unglücklich machen
3. Das Kostbarste auf der Welt st einzig und allein der Augenblick das hier und Jetzt 
4. Deine Reise hat längst begonnen. Irgendwann wirst du sehen, dass du dort angekommst, wo du schon immer warst. Nur lebst du jetzt in einem neuen Bewusstsein. Dem Bewusstsein der Achtsamkeit. Es ist alles schon da. Immer da gewsen in dir.

## Who Should Read It?

# ☘️ How the Book Changed Me

<aside>
💡 How my life / behaviour / thoughts / ideas have changed as a result of reading the book.

</aside>

- Wahre glücksmomente im leben finden ohen Ego statt
- Erfolg ist das was folgt, wenn du dir selbst folgst
- Du kannst dir große Ziele suchen, aber letztendlich sind es die kleinen Dinge in unserem Alltag, die uns zeigen das wir glücklich sind
- Es gibt keinen Weg zum Glück, glücklichsein ist der Weg
- Sei nicht am Ergebnis interessiert, sondern am Erlebnis
- Wenn ich alles was ich tue, mit höchster Achtsamkeit und höchstem Bewusstsein tue, werde ich mich immer glücklich fühlen
- Das Leben ist ein Spiel und wenn du willst das leute etwas nichtmehr tun, gib ihnen zuerst viel dafür es zu tun und reduzeire den Betrag immer wieder bis er minimal wird ⇒ dadurch verlieren sie an Freude

# ✍️ My Top 3 Quotes

- Kein Problem kann auf derselben Bewusstseinsebene gelöst werdedn, auf der es egschaffen wurde ~Albert Einstein
- lebe im Jetzt denn die Herrschaft über den Augenblick ist die Herrschaft über das Leben ~Marie von EbnerEschenbach
- Ich weiß das ichh nichts weiß ~Sokrates
- The chase is better than the catch ~Scooter
- Die wahre vollendung des Menschhen liegtg nicht in dem was er besitzt, sondern in dem was er ist ~ oscar wilde
- Wer einmal sich selbst gefunden hat, kann nichts auf dieser Welt mehr verlieren ~Stefan Zweig

# 📒 Summary + Notes

- Auszeit Warum die Reise vom Kopf zum Herzen die längste unseres Lebens ist
    
    Ressources
    
    Wer Leistung will muss Sinn bieten 
    
    Du musst erstmal leer werden, von all dem was du bisher gelernt hast. Denn nur die Leere kann gefüllt werden 
    
    du musst dich erst von den Problemen lösen, bevor du sie lösen kannst 
    
    Die Reise zu den Antworten wird meiin ganzes leben andauern 
    
    Es geht nicht darum ständig neue Länder zu bereisen, sondern die Welt mir anderen Augen zu sehen 
    
    Actions
    
    hinterfrage den eigenes Selbstverständnis 
    
- Mehr Klarheit ohne Verstand ⇒ Warum wir zwar tun, aber nicht wollen können, was wir wollen
    
    Ressources
    
    Erkenne dich selbst 
    
    Der Mensch kann zwar tun, was er will, aber er kann nicht wollen was er will
    
    Wer recht hat, ist uninteressant, alles neue und Fremde wird vom Menschen zunächst als Bedrohung empfunden
    
    Die 3 Stadien 
    
    Zuerst wird das unbekannte lächerlich gemacht 
    
    Dann wird das unbekannte bekämpft
    
    Dann wird das unbekannte kopiert 
    
    **Nur der Unwissende wird Böse, der Weiise versteht**
    
    Actions
    
    Werde der du bist
    
- Wenn der Problemlöser das Problem ist ⇒ warum Lebenskrisen letztlich immer Wahrnehmungskrisen sind
    
    Ressources
    
    Lehrer können immer nur impulsgeber sein, innere Potentiale freisetzen, Talente kristallisieren und sie können uns zeigen, dass uns niemand im Weg steht außer uns selbst
    
    Kein Problem kann auf derselben Bewusstseinsebene gelöst werdedn, auf der es egschaffen wurde 
    
    Entäuschung setzt Erwartung vorraus
    
    Nicht das Ereignis, sondern unsere Wahrnehmung, also unsere Reaktion auf das Geschehene, die Dinge auf eine bestimmte Weise erscheinen lässt
    
    Jedes Ergeignis ist neutral, wir allein snd dafür verantwortlch, wie wiir die Erignisse tag für tag leben 
    
    Es gibt keine Sachprobleme, nur Kommunikationsprobleme
    
    Bei gleicher Umgebung, lebt doch jeder in einer eigenen Welt 
    
    Der beobachter bestimmt das beaobachtete, dasselbe ereignis kann völlig unterscheidlich wahrgenommen werden ⇒ die schönheit liegt im Auge des Betrachters
    
    Nichts und niemand kann uns glücklich machen, allenfalls unsere Erwartungen erfüllen. Demzufolge kann uns aber auch nichts und niemand unglücklich machen
    
    Life is what happens while you are making other plans ~ John lennon 
    
    Actions 
    
    überprüfe deine Wahrnehmung immer Kritisch
    
    Um den Sinn deines Lebens zu erkennen musst du dir Probleme/Herausforderungen schaffen ⇒ kein problem keine Wachstumsmöglichkeit 
    
- Gestern? Vorbei! Morgen? Kommt Nie! - Leben im hier und Jetzt ⇒ Warum Zeit eine Illusion und Akzeptanz der Schlüssel zum Glück hat
    
    Ressources
    
    des Glückes tod ist der vergleich
    
    Leben
    
    Du bist nicht dafür verantwortlich was geschieht, sehr wohl aber dafür wie du mit den Ereignissen in deinem leben umgehst 
    
    Du bist verantwortlich für deine Erwartungen, Hoffnungen, wünsche und Befürchtungen
    
    nichts und niemand kann dich unglücklich machen außer du selbst
    
    Die größten Schlachten des Lebens tragen wir letztlich in uns selbst aus
    
    Du kannst im Leben nicht alles im Griff haben, die Lebensverändernden Entscheidungen liegen nicht in deinen Händen, sondern passieren immer rein zufällig
    
    Glück
    
    Wir scheitern nicht an dem was ist, sondern an unsern Ansprüchen 
    
    Wahre glücksmomente im leben finden ohen Ego statt
    
    Glücklich ist wer vergisst, was nicht zu ändern ist 
    
    Angst
    
    Angst birgt viel Potential und kann als energieform rchtiig erkannt sehr motivierend wirken
    
    Angst als Alarmsystem ist unser Freund und nicht unser Feind
    
    In dem Moment, in dem wir unsere Angst akzeptieren löst sie sich bereits auf
    
    zukunft vergangenheit
    
    Immer auf die Zzukunft zu schauen bedeutet zu verpassen, was um dich herum passiert, um auf etwas zu warten, das viielleicht niemals eintritt 
    
    Wir sind auch oft im Nachhinein noch lange Zeit mit Ereignissen beschäftigt, die längst hinter uns liegen in der vergangenheit ⇒ wie lange wollen wir diesen Rucksack aus bballast noch mit uns rumschleppen ? Wir sollten gute Erinnerungen schätzen und aus schlechten lernen, aber unsere Vergangenheit nicht zum Stein auf unserem herzen werden lassen
    
    Das Kostbarste auf der Welt st einzig und allein der Augenblick das hier und Jetzt 
    
    sich überaschen zu lassen bedeutet mehr zu bekommen als erwartet
    
    Actions
    
    Finde das Glück in dir Selbst, Wunschlos glücklich sein und Akzeptiere was ist 
    
    Alles was dich wirklich berührt, wirst du ne beeinflussen können
    
    Nicht gelebte Angst ist ein Grund dafür warum bestimmte Dinge immer wieder unseren Weg kreuzen 
    
    lebe im Jetzt denn die Herrschaft über den Augenblick ist die herrschaft über das Leben
    
    Planung gibt sicherheit. Lebensfreude kommt jedoch von wo anders. Die wirklich großen Dinge im leben sind selten geplant 
    
    Ich versuche mein Leben im hier und jetzt zu leben und sehe zeit allenfalls als eine pragmatische hilfskonstruktion an, mit der wir unseren Alltag im Einklang mit andern Menschen leben können
    
    Akzeptiere was ist 
    
    Versuche mit deinen fuzzis zu kommunizieren, die stimmen in deinem Kopf
    
    entscheidend ist nicht was man gibt, sondern das man gibt 
    
    Beginne die Kleinigkeiten im leben mit humor zu sehen, Humor wirkt schmerzlindernd und lachen hilft unsere Angst aufzulösen 
    
- Es gibt keine Richtigen Entschheidungen ⇒ Warum wir keine Fehler machen können und alles seinen Preis hat
    
    Ressources
    
    - Fehler werden nicht gemacht, sondern passieren
    - Das Leben kann nur in der rückblickend verstanden werden, aber nur nach vorne blickend gelebt werden ⇒ wir treffen nur Enscheidungen, weder positiv noch negativ
    - wenn du dir total sicher bist, etwas sei nicht das richtige für dich, hast du IMMER die Möglichkeit, etwas zu verändern ⇒ love it change it or leave it
    - Ich kann nicht heißt nur == der Preis ist mir zu hoch !
    - übernimm Verantwortung für dein Handeln und dein Leben, anstatt Ausreden zu finden, denn alles was du tust, hast du völliig freii gewählt
    - Menschen verändern sich aus 2 dingen
        1. wenn der Leidensdruck zu groß ist Kensho Schmerz Leid
        2. weil die Leindenschaft sie packt Satori Einsicht Leidenschaft 
    - motto: Hier ist die Idee, wo ist die Energie, um diese Idee umzusetzen ?
    - Die lust auf Bequemlichkeit mordet die Leidenschaft der Seele
        - durch die Leidenschaft lebt der Mensch, durch die Vernunft existiert er bloß
    - Die wichtigste zutat der Formel zum Erfolg ist das Wissen, wie man mit Menschen umgeht
    
    Actions
    
    - entweder du nimmst dir die Zeit, oder es ist dir nicht wichtig genug
    - Niemand ist dazu da deine Erwartungen zu erfüllen, außer du selbst
    - Gebe jeden Tag, denn wir Menschen empfinden froße Freude am Geben
    - Akzeptiere dein Dasein, wie es ist, oder fang an deine Träume zu verwirklichen
- Immer nur Sonne macht die Wüste ⇒ warum erfolg und Niederlage gleichgültig sind
    
    Ressourcen
    
    - love goes without saying
    - tausche entweder oder zu sowohl als auch
    - Alles was wir wahrnehmen, haben wir als Entsprechung auf irgendeine Art und Weise bereits in uns. Erst diese Eigenresonanz ermöglicht es uns, eine Nachricht zu verstehen
    - Wahre Freude gibt es nur im doppelpack mit Leid
    - Es kommt gar nicht so sehr auf deine Ziele an, denn sie sind Etappenziele, sondern darauf, wie du den Weg gestaltest
    
    Actions
    
    - gleichgültig ob du im Leben oben oder unten bist, vergiss nie: Auch dies wird vorübergehen ⇒ das Leben ist ein Auf und Ab wie die Unendlichkeit
- Nach dem Spiel ist vor dem Spiel ⇒ Warum wir die Spiele des Lebens nur spielen aber nicht gewinnen können
    
    Ressourcen
    
    - Das leben selbst ist nicht mehr aber auch nicht weniger als ein Spiel
    - nur wer das Spiel aufgibt hat es verloren
    - Was zählt, ist, was wir tatsächlich mit unserem Leben anfangen, wie wir es leben, wie wir unser Spiel spielen, wie wir mit unseren Mitmenschen umgehen und ob wir glücklich und zufrieden dabei sind
    
    Actions
    
    - Du kannst das Spiel des Lebens nicht gewinnen, du kannst nur spielen
    - Die eigentliche Herausforderung ist, Leidenschaft für das zu empfinden, was wir jetzt gerade tun
    - Regel des Lebens: man muss sich immer wieder neuen Herausforderungen stellen
- Erfolg macht traurig ⇒ warum noch nie jemand angekommen ist
    
    Ressourcen
    
    - nichts und niemand kann uns glücklich machen, außer uns selbst
    - Vorfreude ist die schönste Freude und wer sich zu frfüh freut, freut sich öfters 2mal
    - Der höhepunkt unseres Berufes, ist oft der traurigste Moment in unserem Leben
    - Gehabt zu haben, befreit vom Habenmüssen
    - Die freuude liegt auf dem Weg, denn wenn wir unser Ziel erreicht haben und Meister in einer Disziplin geworden sind, müssen wir bald wieder Schüler in einer anderen werden
    
    Actions
    
    - Wahre Freude entsteht ungeplant, sie kommt überraschend und unerwartet und entzieht sich der Kontrolle unseres Verstandes
    - Du kannst dir große Ziele suchen, aber letztendlich sind es die kleinen Dinge in unserem Alltag, die uns zeigen das wir glücklich sind
    - Erfolg ist das was folgt, wenn du dir selbst folgst
    - Es gibt keinen Weg zum Glück, glücklichsein ist der Weg
    - Ist dein Beruf auch deine Berufung ?
- Selbst verwirklichen ⇒ Warum wir eigentlich arbeiten
    
    Ressourcen
    
    - Alles was wir tun, um zu, tun wir nicht für uns selbst, sondern in Abhängigkeit von eiinem äußeren Ereignis
    - Wer also arbeitet um zu, lebt eigentlich am leben vorbei
    - All that I have done, i have done for the fun of it
    - Es soll nicht darum gehen zu tun was man liebt, sondern zu lieben was man tut
    - Extrinsische Motivation ⇒ unser Ego wird bestochen oder ist bedroht ⇒ mittel zum Zweck
    - Das Leben ist ein Spiel und wenn du willst das leute etwas nichtmehr tun, gib ihnen zuerst viel dafür es zu tun und reduzeire den Betrag immer wieder bis er minimal wird ⇒ dadurch verlieren sie an Freude
    - Intrinsische Motivation ⇒ nachhaltig und erfüllend
    - Erst gehabt zu haben, befreit schließlich vom haben müssen
    - Die wahre vollendung des Menschhen liegtg nicht in dem was er besitzt, sondern in dem was er ist ~ oscar wilde
    - Mitarbeitermotivation
        - achte auf dedn Menschen selbst, auf seine inneren Beweggründe und werte
        - Führungskräft können nicht motivieren und inspirieren, da echte, also intrinsische Motivation immer nur in der Tätigkeit selbst liegt
        - Wertschätzung, inspiration, Freiheit, wohlbefinden fördern
    - Sobald sicherheit gewährleistet ist, gehte s darum erneut unsicherheit zu erfahren
    - Alles mit dem wir uns beschöftigen trägt zu unserem Inneren Wachstum bei, everything is a vehicle of our personal growth
    - Stufen der Arbeit
        1. Existen sichern
        2. Leben im sicheren Hafen der Gewohnheit  
        3. Leben und Arbeit im Gleichgewicht 
        
        Von der Raupe zum Schmetterling ⇒ solang du noch eine Raupe bist(EGO) kannst du noch nicht fliegen. Um dein Potenzial zu nutzen musst du erst zum Schmetterling (SELBST) werden 
        
        Die meisten Menschen bemühen sich eine bessere Raupe zu sein, aber wir brauchen Transformation ⇒ eine innere Umkehr ⇒ selbstverwirklichung ⇒ motiv: Liebe 
        
        1. Transformation ⇒ umwandlung in etwas Neues
        2. Innere Wachstum am Höhepunkt ⇒ können wir anderen davon etwas abgeben GEBEN
            1. Wir arbeiten um einen Beitrag zu einer Welt zu leisten, in der wir leben möchten 
        3. Kulmination aller anderen Studen 
            1. wir sind einfach was wir sind, alles andere stellt sich ein 
    
    Actions
    
    - Sei nicht am Ergebnis interessiert, sondern am Erlebnis
    - Warum tust du das was du gerade tust ?
        - Darum ⇒ aus freude am tun
    - The chase is better than the catch ~Scooter
    - Du musst möglichst von Anfang an etwas sein, etwas tun, was dich glücklich macht
    - Wenn ich alles was ich tue, mit höchster Achtsamkeit und höchstem Bewusstsein tue, werde ich mich immer glücklich fühlen
    - Welchen Beitrag zu einer Welt, in der ich leben möchte, kann ich leisten ?
    - In welcher Stufe stehst du und wie kannst du aufsteigen ?
- Sieger Erkennt man am start - Verlierer Auch ⇒ Warum es allein auf unsere Einstellung ankommt und alles schon da ist
    
    Ressourcen
    
    - Es lst immer unsere Einstellung, die zu besstimmten Verhaltensweiisen führt
    - Man erkennt Sieger und Verlierer schon am Start, denn es geht um nichts anderes als die ganz persönliche Einstellung
    - Das was wir denken bestimmt den Ausgang, die Angst davor, dass etwas schiefgeht, führt zu dem vorrausgesehenen Ereignis
    - Wenn der Kopf nicht mitmacht, macht der Körper es auch nicht
    - Wir können unser Verhalten nicht ändern, ohne zuerst an unserer Einstellung zu arbeiten.
    - Unser Gedanke, also unsere Einstellung bestimmt unser handeln
    - Wahre schönheit kommt von innen ⇒ denn es ist unsere Einstellung, die dafür verantwortlich ist
    - Das resonanzgesetzt wirkt ⇒ umgib dich mit positiven worten
    - Die wirkungsvollste Methode deine Einstellung zu ändern ist die Meditation
        - damit kann es uns gelingen ein zufriedener ausgeglichener und glücklicher Mensch zu werden
        - Alle monotonen Ereignisse bringen den Menschen ins eine Mitte und zu siich selbst
    - Wer einmal sich selbst gefunden hat, kann nichts auf dieser Welt mehr verlieren ~Stefan Zweig
    - Das höchste was en Lehrer erwarten kann ist, Menschen an das zu erinnern, was sie immer schon wussten
    
    Actions
    
    - Der Fluss des lebens trägt die wichtigsten Ereignisse in unserem leben ungeplant herran
    - Es kommt darauf an das du die passende Einstellung hast
    - Du musst heute sein, was du morgen werden willst
        - wage dich immer ein stückchen weiter vor als du dir gerade zutrauen würdest
    - es ist unsere Persönlichkeit die zählt
    - People buy from people they like
    - Überlege dir 5 Gründe warum man gerade dich einstellen sollte ?
    - Nenne 5 Gründe warum man dich nicht entlassen sollte ?
        - Was macht dich besonders
    - Beobachte Achtsam was in dir vorgeht und lass die Fuzzi(ego)stimmen in deinem Kopf dich nicht manipulieren
    - Klebe Postits an orte wo du oft hinschaust
    - Gelange Morgens und Abends in den Alpha Zustand
    - Betrachte öfters den Sonnenuntergang
        - geh Joggen, schwimmen, wandern, spazieren, stricken, töpfern, malen, gärtnern, bügeln, mähen
    - Umso öfters du Achtsamkeit praktizierst umso schneller gelangst du in den zustand der Selbst zu freiden heit ⇒ Klarheit ohne Verstand, denn alles fängt damit an leer zu werden und sich von vorgefertigten Meinungen zu verabschieden
    -