# Zufriedenheit, Dankbarkeit

Ursprung: Büchern, Mindvalley
Stehe ich dahinter: Ja, happiness in the now, sei Zufrieden und dankbar für das was du hast