# Entdecken/Neugier

Ursprung: Familie/Kindheit
Stehe ich dahinter: ja, immer neues wissen, neue wege gehen, normal ist langweilig