# Selbstständigkeit

Ursprung: Eltern
Stehe ich dahinter: ja ich versuche die Dinge selbst anzugehen