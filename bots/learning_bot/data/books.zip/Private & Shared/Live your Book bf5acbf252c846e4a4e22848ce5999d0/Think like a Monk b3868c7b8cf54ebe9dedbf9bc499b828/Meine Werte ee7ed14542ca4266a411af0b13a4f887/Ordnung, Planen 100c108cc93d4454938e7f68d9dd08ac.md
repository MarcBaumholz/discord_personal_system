# Ordnung, Planen

Ursprung: Eltern
Stehe ich dahinter: Ja, beginne wichitges, es muss nicht gleich fertig sein, aber beginne es. Du brauchst einen Plan im Leben