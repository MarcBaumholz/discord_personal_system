# Zusammenhalt, Gemeinschaft

Ursprung: Freunde
Stehe ich dahinter: Ja, eine Gemeinschaft, zusammen mehr erreichen, in einer Gruppe sein ist mir wichtig, mit anderen zu sein