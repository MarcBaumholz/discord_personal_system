# Freundlichkeit, Empathie

Ursprung: Ich selbst
Stehe ich dahinter: Ja, immer offen sein für neues und jedem gleich begegnen