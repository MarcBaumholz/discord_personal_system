# Agilität, Flexibilität

Ursprung: Das Leben
Stehe ich dahinter: Ja, durch immer neue Erkenntnisse und Erfahrungen muss man sich anpassen und neues wagen