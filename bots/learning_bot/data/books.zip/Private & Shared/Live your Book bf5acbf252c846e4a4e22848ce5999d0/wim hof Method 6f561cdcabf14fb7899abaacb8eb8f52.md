# wim hof Method

Author: Wim hof
Fiction?: Non-Fiction
Rating: 4-Star
Notes Status: Notes in review

# 🚀 The Book in 3 Sentences

1. Breath motherfucker. Go deep into the Ice. Start taking control about your body and life.

# 🎨 Impressions

## How I Discovered It

Following wim hof

## Who Should Read It?

everybody who want to have a health improvement, more energy, more clarity, more love and happiness in life

# ☘️ How the Book Changed Me

<aside>
💡 How my life / behaviour / thoughts / ideas have changed as a result of reading the book.

</aside>

- Go more often in Nature
- Remind myself how powerful the cold is, feel it and do it, train muscle of beliefe and mind
- I can increase tempreture in parts of my body with my mind
- Atmung Bauch Brust kopf
- Morgens sind wir sauer ⇒ sollten basisch sein ⇒ morgens wim hof atmung ⇒ produktivitätstrick ⇒ gehirn im besten Zustand nach Atmung

# ✍️ My Top 3 Quotes

- When we hold the breath we are fully present and have a deep connection to our body and soul
- Breath is the lifeforce

# 📒 Summary + Notes

The breath releases stuck energy, access emotions, is perfect for visualisation, a natural high, become more hole, ⇒ can reduce pain 

Gegen Kater: kalte dusche und 20min Wim Hof Atmung ⇒ hangover weg

Help against autoimmune disease, enjoy life, purpose, health, strength, happiness, never sick, against stress, alcolice the body ⇒ natural state ⇒ entsäuern 

Help against Depression, Insomania, sleep pain, chronic pain, backpain, mood, arthritis, immune system

Breath increase the lactic threshold

Breath can calm sexual arrousal

Breath and cold shower ⇒ release adrenalim