# Definiere dich Neu

Author: ishen Lakhiani
Fiction?: Non-Fiction
Genres: Creativity, Life Advice, Mindfulnes, health
Notes Status: Notes in review
Page: fertig

# 🚀 The Book in 3 Sentences

1. 

# 🎨 Impressions

## How I Discovered It

## Who Should Read It?

# ☘️ How the Book Changed Me

<aside>
💡 How my life / behaviour / thoughts / ideas have changed as a result of reading the book.

</aside>

- 

# ✍️ My Top 3 Quotes

- 

# 📒 Summary + Notes

- Erstens Leben inmitten deines Umfelds - Erkenntnis
    
    Ressources
    
    - Wachse durch Unbehagen oder Einsicht
    - Jeder kann beschließen eine außergewöhnliche Persönlichkeit zu werden
    - Lerne die Regeln der Welt in der wir leben in frage zu stellen
    - Alles was wir so das leben nennen, stammt von leuten die auch nicht schlauer sind als du
    - Vieles was du so für war hältst ist es nur in deiner Vorstellung
    - Auf nummer sicher zu setzen hält uns von einem Leben voller Sinnhaftigkeit und Entdeckungen ab
    - Wenn du nicht gewinnen kannst, verändere die Spielregeln. Und wenn du nichts an den Regeln ändern kannst, ignoriere sie eben
    - Welche Bullshit Regeln gibt es BRULES
        - Kindheit, Erzeihung, Authoritätspersonen, Umfeld zugehörigkeitsgefühl, innere Unsicherheit, Soziale Beeinflussung,
    - Hinterfrage die Regeln denen du folgst
    - picke dir aus allem was du lernst und was dir geschieht die elemente heraus, von denen du dich besonders angesprochen fühlst
    - Unsere Zeit ist begrenz, vergeude sie nicht, indem du das leben eines anderen führst.
    - Lass nicht zu das deine innere Stimme von Meinungen anderer übertönt wird
    - hab den Mut deinem Herzen und deiner Intuition zu folgen
    
    Actions 
    
    - suche dir systematisch Menschen die einen schritt voraus sind und befrage sie
    - Such dir unbedingt eine Beschäftigung die du liebst
    - Brules Test
        - beruht die Regel auf Vertrauen in und Hoffnung auf der Menscheit ?
        - Verstößt sie gegen die Regel, behandle jeden so, wie du selbst behandelt werden möchtest ?
        - Entstammt sie meiner Kultur oder Religion ?
        - Beruht sie auf rationaler Entscheidung oder sozialer Ansteckung ?
        - Dient sie meinem Glück ?
    - Koste deine kostbare Lebenszeit voll aus, bleib dir treu und habe ein offenens herz und einen aufgeschlossenen Geist, sowie den Mut alles zu verändern, was für dich nicht mehr funktioniert und die Konsequenzen zu tragen
- zweitens Das Erwachen - Eigene Regeln
    
    Ressources
    
    - wir wachsen durch das ändern unserer Routinen und das ändern unserer Glaubenssätze
    - Lebensbereiche
        - Liebesbeziehung, Freunde, Abenteuer, Umgebung, Gesundheit, Intellektuell, Spirituel, Beruf, Kreativität, Fähigkeiten, Familie, Gemeinschaftsleben
    - Warum fragen sind pure Interpretation, was fragen stellen klar in den Vordergrund was passiert ist
    
    Actions 
    
    - höre auf deine innere Stimme die Intuition
    - lerne dich regelmäßig selbst zu hinterfragen
    - finde leute die Klüger sind als du
    - definiere dir deine Lebensbereiche, was glaubst du in jedem Lebensbereich, definiere Klare set poitns was machst du mindestens
- Drittens Programmiere dich Neu - Glück und Erfüllung
    
    Ressources
    
    - unsere Überzeugungen formen die Welt
    - Halte an deinen großen Zielen Fest, aber verknüpfe bloß dein Lebensglück nicht damit Sei lieber jetzt schon glücklich und zufrieden
    - wenn du in der Gegenwart leben kannst, bist du glücklich
    - lass Arbeit und Spiel verschmelzen
    - wir sollten nie etwas tun um glücklich werden zu können. SOndern sollten immer glücklich sein, um überhaupt etwas erreichen zu können
    - Eine Vision sollte ebenso deine Sele ansprechen
    - Unfuckwithable
        - Wenn du inneren Frieden verspürst und ganz bei dir bist. Nichts was irgendjemand sagt oder tut kann dich dann noch aus der Ruhe bringen. Und alle Negativität perlt an dir ab
    - Gutes tun verleit dem Leben sinn
    - Unterscheide zwischen Zweck ( um XYZ) und Bestimmungszielen ( wachstum, erfahrung, geben)
    - Bestimmungsziele
        - folge deinem Herzen, ein gefühl,
        - wie wilst du in deinen Lebenskategorien Wachsen, welche erfahrungen willst du machen, wem willst du helfen
    
    Actions
    
    - Was verstehe ich unter Glück und wie kann ich bereits jetzt damit zufrieden sein
    - folge dem Gesetz der Anziehung
    - nutze den Happiness Advantage
    - beginne und beende deinen Tag in Dankbarkeit
    - Gebe anderen, helfe
    - praktiziere Vergebung zu dir selbst und zu anderen
    - kreiere deine Liste an Zielen und druck sie visuell aus und häng sie auf
- Viertens Ausergewöhnlich werden - Menschheit vorranbringen
    
    Ressources 
    
    - Finde deine Berufung am Leben zu sein
    - die Furcht vor Verlust ein Pfad zur dunklen seite ist ~Yoda
    - du musst loslassen von den dingen, vor denen du dich fürchtest sie zu verlieren
    - Dein Lebensglück ist nur von dir selber und von niemand im außen beeinflussbar
    - was du steuern kannst ist wie du in jeder situation reagierst und welche Bedeutung du der Situation zuschreibst
    - das Problem der meisten Menschen ist, dass ihre Probleme zu klein sind
    - Problem ⇒ Frage ⇒ Antwort ⇒ Handlung ⇒ Lebenspraxis
    
    Actions
    
    - Bezieh liebe und Erfüllung aus deiner inneren Quelle und nicht von außen
    - Setze dir Ziele die stets und immer unter deiner Kontrolle liegen
    - sei präsent
    - in welcher hinsicht möchtest du die Welt zum positiven verändern
    - wenn du nicht weist was du tun sollst, mach einfach einen winzigen baby schritt und dann den nächsten
    - practice the 6 phase meditation
        - mitgefühl, dankbarkeit, vergebung, zukunftsvision, perfekter tag, segnung