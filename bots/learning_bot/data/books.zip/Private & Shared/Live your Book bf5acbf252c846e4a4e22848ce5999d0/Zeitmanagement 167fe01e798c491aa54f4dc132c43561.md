# Zeitmanagement

Fiction?: Non-Fiction
Notes Status: Notes in review

# 🚀 The Book in 3 Sentences

1. 

# 🎨 Impressions

## How I Discovered It

## Who Should Read It?

# ☘️ How the Book Changed Me

<aside>
💡 How my life / behaviour / thoughts / ideas have changed as a result of reading the book.

</aside>

- 

# ✍️ My Top 3 Quotes

- 

# 📒 Summary + Notes

Ressources

- Ziele, prioritäten, Pläne, Fokus, Habits, niemals aufgeben

Actions

- Ziele
    - Welchen zustand möchtest du erreichen ?
    - Wie sieht dein Ergebnis aus ?
    - Messbar ?
    - Wann erreichen ?
    - konkret, schriftlich, verbindlich
- Prioritäten
    - besonders wichtig ?
    - erfülltes leben ?
    - verzichten ?
- Pläne
    - pläne sind unwichtig aber planen ist alles
    - Ziel des Tages, woche, monat, jahr
    - zwischenschritte
- Fokus
    - single tasking
    - no distractions
- Eat the frog first most important thing
- Pareto 80/20
- SMART Spezifisch, messbar, attraktiv, realistisch, terminiert
- FOkus Frage ⇒ welche ist die eine sache, die ich tun kann das alles andere überflüssig wird
- Salami ⇒ ziele in kleine schnipsel aufteilen ⇒  teilaufgaben
- ABC anaylse ⇒ prios in apc ordnen
- Eisenhower ⇒ Wichtig dringend ,unwichtig dringend ,wichtig nicht dringend, unwichtig nicht dringend
- ALPEN ⇒ Afugaben und Termine aufschreiben ⇒ Länge der aktivität ⇒ Pufferzeit einplanen ⇒ Entscheidungen treffen ⇒ Nachkontrolle
- Getting things Done ⇒ sammeln verarbeiten Organisieren durchsehen erledigen
- Leistungskurve ⇒ produktivzeiten am Tag ⇒ morgens ⇒ kurz nachmittags
- Planungsebenen ⇒ 5 Jahre 3 Jahre 1 Jahr monat Woche Tag
- Parkinsinsches Gesetz ⇒ Arbeit passt sich dem mas der Zeit an die zur verfügung steht
- Time Boxing ⇒ für aufgaben 2h deep work 4h creativität
- Task chunks ⇒ bündeln ähnlicher aufgaben in effizienten blöcken erledigen
- Pomodoro ⇒ 25min 5 pause oder 50 10 pause
- Singletasking
- 2 minuten regel ⇒ dinge die weniger als 2min brauhen müssen nicht geplant werden ⇒ einfach machen
- Speed reading lernen
- Zeit Balance modell ⇒ körper gesundheit ⇒ leisutng arbeit ⇒ kontakt beziehung ⇒ sinn kultur
- Kon Mari Methode ⇒ Ziel festlegen ⇒ Kategorie aufräumen ⇒ kurz Zeit aufräumen ⇒ Glücksfrage stellen ⇒ fester platz
- not to do liste  ⇒ unnötige unproduktive habits
- VIP liste ⇒  menschen du zeit verbringen willst
- Journaling ⇒ dokumentation und planung reflektion
- non zero days ⇒ tag nichts machst