# Tools der Titanen

Author: Tim Ferris
Fiction?: Non-Fiction
Genres: Business, Life Advice, Productivity, entrepreneur
Rating: 8
Notes Status: Notes In Progress
Page: Die Taktiken, Routinen und Gewohnheiten der Weltklasse Performer, Ikonen und Milliardäre
Date Finished: November 19, 2020

# 🚀 The Book in 3 Sentences

1. 

# 🎨 Impressions

## How I Discovered It

Book store

## Powerquestions?

- Was tun Sie, von dem die Welt noch nicht weiß, dass es wirklich etwas ganz besonderes ist?
- Was macht, wenn es erledigt ist alle anderen Aufgaben einfacher oder nebensächlicher?
- 

# ☘️ How the Book Changed Me

<aside>
💡 How my life / behaviour / thoughts / ideas have changed as a result of reading the book.

</aside>

- ASK: was könnten sie tun, um ihre 10 JahresZiele binnen der nächsten 6 Monate zu erreichen, wenn man sie mit einer Pistole bedroht?
- Routine: tägliche Achtsamkeit
- Glaubenssatz: Scheitern dauert nicht ewig
- Gewohnheit: Ausschau nach ungewöhnlichen Wegen
- Routine: Bereite dich auf das Worst case szenario vor
- Routinen: J curls, Schulterextensions, BWS-Brücke
- daily routine: AUsfallschritte, kuh, katze, vor bett gehen auf bauch rollen
- Glaubenssatz: ENtweder bin ich bereit oder nicht, mir jetzt darüber sorgen zu machen wird nichts ändern. Was passiert passiert.
- Routine: Was mache ich zurzeit gewohnheitsmäßig, das ich nicht beherrsche? ⇒ entweder verbessere ich es, lasse es weg oder delegiere es.
- Routine : Meditieren Suche einen Partner
- Routine: Zeige dich und gehe zu Meetings/veranstaltungen, mach dich nützlich, mach notizen
- Glaubenssatz: Sei ungeniert du selbst mit all deinen EIgenarten
- Routine: nutze workouts als Meditationsform, konzentriere dich auf den Muskel
- Glaubenssatz: besitze so wenig wie möglich
- Routine: Experimentiere, starte 2-3 Monatige Projekte und hole das maximale raus
- Regel: Was sie gerade tun, ist wichtiger als wie sie alles andere erledigen, und etwas wird nicht dadurch wichtiger, dass man es besonders gut macht.
- Glaubenssatz: Viel zu tun zu haben, ist eine Form der Faulheit, Sie sind zu Faul zum Nachdenken und ergehen sich in wahlloser Aktivität, wer zu viel zu tun hat, nutzt das oft als Vorwand, um sich vor ein paar Aufgaben zu drücken, die wirklich wichtig , aber unangenehm sind.

# ✍️ My Top 3 Quotes

- Beurteile einen Menschen nach seinen Fragen, nicht nach seinen Antowrten ~Pierre Marc Gaston
- Nehme die Dinge nicht persönlich
- Wenn man bedrückt ist lebt man in der Vergangenheit, wenn man besorgt ist lebt man in der Zukunft, wenn man ruht, lebt man in der Gegenwart
- Wenn man die Botschaft bekommt, die man braucht, sollte man erst dann weiter fragen stellen, wenn man seine Hausaufgaben gemacht hat
- Wer sich abstrus hohe Ziele setzt und daran scheitert, der scheitert weit jenseits von dem , was andere bereits als erfolg fieren ~ James Cameron
- Es geht nicht darum was man weiß, sondern darum, was man konsequent durchzieht~TF
- Wer unter Zeitmangel leidet kann keine Prioritäten setzen

# 📒 Summary + Notes

- Intro
    
    Erkenne deine Stärken und baue Gewohnheiten um diese herum auf
    
- Gesundheit
    
    ⇒ wenn ich loslasse was ich bin, werde ich, was ich sein könnte
    
    ⇒ es ist kein maß für Gesundheit, an eine zufiefst kranke Gesellschaft gut angepasst zu sein
    
    ⇒ gegen Narben, wundauflagen mit Manuka Honig
    
    ⇒[https://shop.humann.com/products/beetelite?subscription=1&variant=34223922118795](https://shop.humann.com/products/beetelite?subscription=1&variant=34223922118795) Beetelite für mehr Ausdauer beim Joggen
    
    ⇒ Sei auf das Worst case scenario Vorbereitet
    
    ⇒ 2 20min saunagäng mit 30min Pause ⇒ Steigert das Wachstumshormon X5 ⇒ Wundheilung
    
    ⇒ Wenn man sich hetzt, wird man mit Verletzung belohnt
    
    ⇒ Übungen: J curls, Schulterextensions, BWS-Brücke
    
    ⇒ [http://ww25.ketogenic-diet-resources.com/?subid1=20210123-0805-11f5-b931-ed42ccbe81c5](http://ww25.ketogenic-diet-resources.com/?subid1=20210123-0805-11f5-b931-ed42ccbe81c5) ⇒ ketogene ernährung
    
    ⇒ verringert Körperfett, Antikrebswirkung, bessere Sauerstoffverwertung, Krafterhalt oder zunahme
    
    ⇒ Fasten reinigt den Körper, 1Jahr 2 bis 3 mal 5 Fastentage einlegen
    
    ⇒ hähnchenfilet, Blattsalat, Olivenöl, Feta, makadamianüsse ⇒ wniger Käse und Milchprodukte
    
    ⇒ Supplemet: MCT Oil powder und Coconut Oil Powder von Quest Nutrition, Bone broth von Kettle & fire
    
    ⇒ Spiele und lass los was nicht fuktioniert, mache genau das was dich motiviert und richtig begeistert
    
    ⇒ effizienteste form der körperlichen aktivität, ist schweres krafttraining
    
    ⇒ schlaffe haut oder dehnungsstreifen ⇒ gotu kola kraut
    
    ⇒ testosteron erhöhren, indem man cortisol(stress) senkt
    
    ⇒ mobiles gym ⇒ vodoo floss(weniger schmerzen), Möbelgleiter(AG walks im rückstütz), Black roal, akkupressurmatte, mini parallettes
    
    ⇒ täglich 3-4 mal 50% der klimzüge die man schafft ⇒ mind 15min pause 
    
    ⇒ nutze floating als eine art verstärkte mediation um in den Uhrsprungszustand zu kommen
    
    ⇒ morgenlatte ⇒ inidkator für hormongesundheit und schlafqualität
    
    ⇒ Flache SCHuhe oder Barfusgehen
    
    ⇒ einschalfen 2 Esslöffel apfelessig und honig mit heißem wasser
    
    ⇒ Wichtig sind die ersten 60-90min des Tages
    
    ⇒ Titan Tee: 1 Teelöffel ⇒ Pu-erh gereifter schwarztee, longjing Grüntee, Kurkuma und ingwerraspeln mit MCT öl 
    
    ⇒ 
    
- Reichtum
    
    ⇒ gehe zu so vielen Meetings wie möglich und suche nach Möglichkeiten dich nützlich zu machen ⇒ mach für sie notizen
    
    ⇒ Heute nacht liege ich in meinem Bett: Ich sagte mir das immer wieder vor, um mir vor augen zu führen, dass die Strapazen vorrübergehen würden.
    
    ⇒ stell die dummen fragen, denn wer zu viel weis, sieht die macken nicht, welche optimiert werden müssen 
    
    ⇒ wir sind emotionsgesteuert und lassen uns von Geschichten faszinieren 
    
    ⇒ wenn man eine ganz klare vision davon hat, wo man hin will, dann ist alles gleich viel einfacher 
    
    ⇒ in Verhandlungen gewinnt der, dem es am wenigsten darauf ankommt
    
    ⇒ finde deine Niesche un dkonzentriere dich voll darauf
    
    ⇒ Der beste Plan ist der der änderungen zulässt
    
    ⇒ Am Anfang nimmst du jede gelegentheit, aber mit der Zeit musst du lernen Nein zu sagen
    
    ⇒ wer unter Zeitmangel leidet, kann keine Prioritäten setzen
    
    ⇒ betrachte dein leben als Experiment, stürze dich alle paar monate in ein neues Projekt
    
    ⇒ wir sind, was wir vorgeben zu sein
    

![](Tools%20der%20Titanen%208b6ec90f8d7f420fa304bc3c5be7b22c/image-1613155773352.jpg316328271.jpg)