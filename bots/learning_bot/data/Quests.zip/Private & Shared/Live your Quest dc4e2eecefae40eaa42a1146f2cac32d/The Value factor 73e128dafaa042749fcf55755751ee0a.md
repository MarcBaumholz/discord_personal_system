# The Value factor

# 🚀 The Quest in 3 Sentences

1. 

# 🎨 What do I use from this Quest ?

## Who Should take this Quest?

# ☘️ How the Quest Changed Me

<aside>
💡 How my life / behaviour / thoughts / ideas have changed as a result of reading the book.

</aside>

- 

# ✍️ My Top 3 Learnings

- 

# 📒 Summary + Notes

w t+1 = wt + n d dx L (f(x,w),y

ht = Ht-1 Wh + Wt * et + bi

at ⇒ softmax Q*Kt / sqrt(dk) d/h *V h number of heads d dimensions 

- intro
    
    R:
    
    - the one thing that measures if people achieve what they really want, is by just follow their values
    - living by what you really value in Life or not
    - Impact of values
    - empower your life with your values
    - living by design not by duty
    - live by priority
    
    A:
    
    - 
- Week 1
    - day 1
    - day 2
    - day 3
    - day 4
    - day 5
        
        R:
        
        - persona enter in a state of being
        - subconcious mind stores the bad words until we are ready for them
        - you have 2 sides, things you take credit for, things you are mean
        
        A:
        
        ![image.png](The%20Value%20factor%2073e128dafaa042749fcf55755751ee0a/image.png)
        
    - day 6
        
        ![image.png](The%20Value%20factor%2073e128dafaa042749fcf55755751ee0a/image%201.png)
        
    - day 7
        
        R:
        
        - 7 Areas
            1. Spiritual ⇒ mediatate ⇒ some inspired mission ⇒ calling in life ⇒ purpose 
            2. Mental ⇒ mind health ⇒ Innovaiton, creativity, genious, thinking ⇒ use the brain
                1. when you live by someone else, you put their values into yours, keep you down, dont adore others  
                2. Dont put people on pedostoles
            3. Vocational ⇒ intellectual learn ⇒ achievemtn, sustainable fair excahnge, success ⇒ fullfillment ⇒ career, do what you love and love what you do
                1. business, do not live by someone else, honor yourself 
            4. Finance ⇒ money ⇒ invest and have enough money left in the end of the month ⇒ 
                1. live your own values ⇒ 
            5. Familial ⇒ family ⇒ love and intimacy ⇒ putting people in your hearth 
                1. you cant let someone else live your values 
            6. Social ⇒ friends ⇒ leaving a legacy, impacting people with who you are ⇒ influence 
                1. dont compare relationship with others ⇒ because you cant 
                2. hire people by understand their highest values 
            7. Physical ⇒ sport ⇒ wellness, attractive, vitality s
        - When you live more empowered you feel like your master of destiny
        - 3 Tools of empowerment
            - Reflection
                - you admire someone by what they can do better,
                - find that trait in a past experience by yourself
                - what you see in others you have
            - neutralisation
                - you admit that trait you admire ⇒ it has also a downside ⇒ all traits are neutral
                - What are the downsites of that trend
            - value linking
                - neutralize pos. and negative
                - be authentic, be yourself, live by hoghest value
        - anytime you put people above or below you and dont put people in your heart, you automatically create a disempowerment
        - SOUL ⇒ state of unconditional Love
        
        A:
        
        - Empower your Life areas
        - there is nothing more powerful than being authentic
        - when you see a. trait, search for when you had that
    - Summary
- Week 2
    - day 8
        
        R:
        
        - live by your highest values
            
            ![image.png](The%20Value%20factor%2073e128dafaa042749fcf55755751ee0a/image%202.png)
            
        - compulsive, impulsive, addictive, behavior is a compensation for not filling your day with high priority actions
        - that is an emidiate quickfix
        - know everything that can go wrong
        - negatves are feedback systems
        - have a balanced life ⇒ good and bad
        
        A:
        
        - pursue an inspired vision, strategically planning and medigate risk
        - have people that are experts and can mitigate your risks, before they appear
        - imagine all possible ways that can go wrong and having a solution in advance
        - anticipate what you want to do
        - have the executive senter that helps to go from fantasy to objective by taking risk and wins into consideration
        
    - day 9
        
        R:
        
        - Every humnan being loves learrning but only whats most important to them
            
            ![image.png](The%20Value%20factor%2073e128dafaa042749fcf55755751ee0a/image%203.png)
            
        - 
        
        A:
        
        - take their top 3 values
        - project your volues to classes and topics they learn there
        - how that that class help you fulfill your value, linked to highest value
    - day 10
        
        r:
        
        - know the values of the people you hire = do the value determination process
        - their values determine what they gonna do
        - be clear on their job description
        
        a:
        
        - access the degree of engagement of the job description and their values, find the links of job descriptions
            
            ![image.png](The%20Value%20factor%2073e128dafaa042749fcf55755751ee0a/image%204.png)
            
        - grateful, enthusiastic in daily actions , inspired by vision, present while they work, loving what they do, certain by their skills
        
    - day 11
        
        R
        
        - have a sustainable self exchange
        - Whatever your highest value is you have your inspiration and your inspiration is your spiritual quest
        - if you dont have a hogh value on wealth building, it is not going to happen
        
        A:
        
        - Do the value determination  process 13 questions and have wealth in the top 4
        - wealth building is buing assets, that goes up in income, that grows assets
        
        ![image.png](The%20Value%20factor%2073e128dafaa042749fcf55755751ee0a/image%205.png)
        
        ![image.png](The%20Value%20factor%2073e128dafaa042749fcf55755751ee0a/image%206.png)
        
        - 
    - day 12
        
        R:
        
        - Relationships there are 2 sides
        - see them who they are
        - you take the angel adn the evil
        - be authentic, and be who you are
        - true love is pure reflective awareness
        - Do not live by someone elses values
        - When you love people for who they are, they turn into who you love
        
        A:
        
        - What is it that you admire on that person?
        - when youa re the under oder overdog = come down or up = find a match = think into them and look that you bring them equal
        - help your partner to get his values that helps your values to happen = respect each other = focus on what you are dedicated
        - your and their top 3 values
            - live your highest values and connect them to each other
            - you cant fix them, how is the value of your partner fit to your value
            - make hunderets of links
                
                ![image.png](The%20Value%20factor%2073e128dafaa042749fcf55755751ee0a/image%207.png)
                
            - 
    - day 13
        
        R:
        
        - those with higher Vision flurish, leaders have visions
        - live by your high priority values
        - be inspired by a mission, be intrinsically driven
        - fill your day with highest priority actions
        - when you are a leader you have something impactful to share
        - finding that one thing that you become excellent at awakens the natural born leader inside you
        - delegate, plan, wake up your leader, prioritise,
        
        A:
        
        - What are you commited to leading
        - What is your mission and Vision
            - how is this job helping to fulfill your highest values
        - write down 5-6 high priority actions that help to fulfill your highest values ⇒ get you one step further towards your dream
        - get the list of 6 daily things that bring you forward to your dream
        - for him: teach, research, write, travel
            - rest is delegated
        - compare daily actions to highest values
    - day 14
        
        R:
        
        - only 2 fears in life, 1. the fear of loss of that which you seek and 2. the fear of gain of that which you are trying to avoid
        - have something deep and meaningful
        - it is important to have challenges that inspire you
        - prioritize your life
            
            ![image.png](The%20Value%20factor%2073e128dafaa042749fcf55755751ee0a/image%208.png)
            
        - pleasure and pain comes often together  ⇒ embrace together ⇒ wellness is we ⇒ illness is I
            - love is wellness
        - dedicate life to highest priority actions
        
        A:
        
        - have challenges that inspires you
        - live by your highest value, it affects your body
        - have a balace of sympatic and parasympatic nervous system
        - your body is trying to get you to authenticity and highest value, balance your life
    - Summary
- Week 3
    - day 15
        
        R:
        
        - the desire for that which is unavailable and the desire to avoid that which is unavoidable is the source of human suffering
        - it is wise to live with holy curiosity and to continue to expand and grow the next day
        - I know nothing, be more humble
            
            ![image.png](The%20Value%20factor%2073e128dafaa042749fcf55755751ee0a/image%209.png)
            
            ![image.png](The%20Value%20factor%2073e128dafaa042749fcf55755751ee0a/image%2010.png)
            
        
        A:
        
        - be inspired every day from within
        - 
    - day 16
        
        R:
        
        ![image.png](The%20Value%20factor%2073e128dafaa042749fcf55755751ee0a/image%2011.png)
        
        A:
        
        - 
    - day 3
    - day 4
    - day 5
    - day 6
    - day 7
    - Summary