# The 3 Most Important Questions

Author: Vishen Lakhiani
Fiction?: Non-Fiction
Genres: Creativity, Life Advice, Productivity, communication, entrepreneur
Rating: 5-Star
Notes Status: notes in review
Duration: 7 days

# 🚀 The Quest in 3 Sentences

1. Experiences Growth Contribution

# 🎨 What do I use from this Quest ?

- Goal Setting Methodology

## Who Should take this Quest?

- everybody in this world

# ☘️ How the Quest Changed Me

<aside>
💡 How my life / behaviour / thoughts / ideas have changed as a result of reading the book.

</aside>

- I know what comes truly from my heart

# ✍️ My Top 3 Learnings

- What do I want to Experience
- How do I want to Grow
- How do i want to contribute

# 📒 Summary + Notes

- INTRO 3 Most Important Questions
    
    
    A:
    
    - Think about the live you want to create
    - listen to your heart
    - Focus on the Why and What and forget the how
    - Make the 3MIQs Visible
    
    R:
    
    - Escape from the culture scape Programmming, culture limit us
    - People are goal driven creatures
    - BRULES ⇒ Bullshit Rules ⇒ make your own rules and stop follow rules from others
    - you can not connect the dots looking forward, only by looking backwards
    - 2 types of goals
        - End Goals  is what lights you up
            - from heart, how is unclear, feeling based
        - Mean goals is like a project to achieve an end goal
            - I do X so I can do Y
    
- Experiences
    
    A:
    
    - 
    
    R:
    
    - Travel, adventure, children, house, …
- Growth
    
    A:
    
    - 
    
    R:
    
    - Transformation, learning, better self, …
- Contribution
    
    A:
    
    - 
    
    R:
    
    - help, make others happy, …