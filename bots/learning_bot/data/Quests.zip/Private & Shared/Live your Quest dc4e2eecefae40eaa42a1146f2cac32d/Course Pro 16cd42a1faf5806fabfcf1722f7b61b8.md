# Course Pro

# 🚀 The Quest in 3 Sentences

1. 

# 🎨 What do I use from this Quest ?

## Who Should take this Quest?

# ☘️ How the Quest Changed Me

<aside>
💡 How my life / behaviour / thoughts / ideas have changed as a result of reading the book.

</aside>

- 

# ✍️ My Top 3 Learnings

- 

# 📒 Summary + Notes

- Week 1
    
    Ressources
    
    - if you want to change the world, change education
    - your weakness quantifies you to be an incredible teacher if you overcome it
    - connect with vulnerability
    - MOOCs, massive open online course on low cost,
    - CBC Cohort based course, join on fixed date, start of week, students in class, byte size junks, start and end date, create a clear commitment, daily lesson, have a community sahre with students/friends,
    - live classes too for questions
    
    Actions
    
    - create 3 types of avatars for your online course , but all are connected
        - still to nervous to do it, people who have ideas, people who do the ideas but want to do it better
    - What course Do I want to create  ?
        - Reading, startups ecosystem, talking to people networking, speaking, introversion, online courses, education, habits got nothing done, systems like a programmer, orientation passion purpose, creating Ideas as a habit
    - What is my end goal in building my course ?
        - help others who struggled at the same parts as I struggled in the past
        - Share my Passion, Purpose
    - What problem can it solve ?
        - System thinking, connecting the dots, creating ideas
    
    Day 1 How course creation can change your life
    
    R:
    
    - have more often things people need to pause and do something
        - then share your own learnings with it within a story
    - create a compelling vision, it helps create a legacy, earn money, building a strong brand
    - if somebody google your name, what will they see ?
    - when you give something premium for free, they want to give back
    
    A:
    
    - Where do you see yourself 1 year from now ?
        - masterclass, series of courses
        - start academy, have the ressources to start a business
        - created systems people follow
    - Showcase your content online and offer free access to premium programs
        - when meeting clients this is a good product
    
    Day 2 Why your  fears are an illusion
    
    R:
    
    - 
    
    A:
    
    - what fears do I have ?
        - I am too young
        - I am not ready, I need more experience
        - My Family and friends will laugh at me
        - nobody will buy my course
    - commit financially and puplically
- Week 2
    
    Ressources
    
    - 
    
    Actions
    
    - 
- Week 3
    
    Ressources
    
    - 
    
    Actions
    
    - 

# 📒 Things I still apply

## 💪 My Journey

- Week 1
- Week 2
- Week 3