# A Journey to Infinitheism

Author: Mahatria
Fiction?: Non-Fiction
Notes Status: notes in review
Duration: 21
progress: finish

# 🚀 The Quest in 3 Sentences

1. 

# 🎨 What do I use from this Quest ?

## Who Should take this Quest?

# ☘️ How the Quest Changed Me

<aside>
💡 How my life / behaviour / thoughts / ideas have changed as a result of reading the book.

</aside>

- 

# ✍️ My Top 3 Learnings

- 

# 📒 Summary + Notes

- Part 1
    
    Ressources
    
    - the mind of the man is the man => when you change your mind you change your life
    - 3 relationships you need to get right
        - with yourself ME
        - with others WE
        - with the big thing THEE
    - you can only be the best version of yourself and it all starts by loving yourself
    - the unit of measurement of life is experiences
    - where can I change myself ?
        - sometimes I can not change myself, but I can change my approach towards the world
    - growth requires change
    - before and after change you are comfortable, but the transistion was never comfortable
    - growth is nothing like going from lesser comfort to higher comfort through uncomfortable transition
    - your attitude will make or break you
    - the language of life is "I CAN "
    - the ultimate goal is peace and happiness and happiness is the journey
    - it is only a question of time when you will achieve it
    - you do not get what you desire, but what you deserve
    - the power lies in the subconcious mind
        - it cant distinquish between good and bad only between shallow and deep emotions
        - feed it wisely
    
    Actions
    
    - love yourself every day
    - When you take full responsibility for what happens in your life without blaming others or the world, you improve your quality of life, experiences, and interaction with the world.
    - Whack when you blame
    - tap shoulders when take full responsibility
    - stop procrastinate on thinfs that you know are right for you
    - What is one pleasure I can stay away from ?
    - What is one thing I associate with pain, but I know it is right for my life
    - What is your attitude today ?
    - What is one goal that truly reflects my behaviour ?
    - use creative visualization to manifest things in life
    - bring enthusiasm in your life, celebrate it daily
- Part 2
    
    Ressources
    
    - "U-TURN”(YOU TURN) means going beyond your ego by stopping from proving yourself to others.
    It means showing people how much you love them by changing yourself or changing your approach towards them.
    - by providing the other person wrong you do not get the relationship right
    - my life is my responsibility and no blaming is allowed
    - we love people and use things
    - drop guilt by forgiving yourself
    - drop hurt by forgiving others
    - love does not guarantee happiness, but happiness guarantees love
    - when we are emotional, our intelligence takes a backseat
    - abstain from action and decision-making in an emotional environment
    - the time to correct the mistake is never during the mistake
    - I understand or feeling with your feeling are empowering sentences
    - people will spend time with you because you make them feel special
    
    Actions
    
    - bring touch (hugs) back to your relationships
    - stop take yourself to serious, instead laugh at yourself more frequently
    - show interest in what they are interested in, they find you interesting and whoever they find interesting, they see a friend in them
    - In a fight, take a break and get clear by your own and then come back
    - **It is not about what you feel for me, It is about how
    you make me feel when i am with you**
- Part 3
    
    Ressources
    
    - spirituality is not how you look, it is about who you are
    - the proof of your spiritual evolution is in the manifestation of peace
    - your attitude about complaining for everything in life, is not giving you peace => a complaining mind is never peaceful
    - we have a control over a choice, but we cannot control the consequence
    - journey is life, celebration of process is celebration of life
    - every end is nothing like a new beginning, every finishing line is the new starting line
    - You can sustain transformation and change by staying in touch with the teacher, the teachings, and like-minded people
    
    Actions
    
    - What would your life look like, if you could experience a depth of peace in the midst of challenges?
    - accept the unchangeable, change the changeable and remove yourself from the unaccecptable
    - **When feel negative emotions**
        
        **What am I not accepting that is disturbing me ?**
        
        **Who am I not accepting who is disturbing me ?**
        
        no blaming is allowed
        
        turn not acceptance into acceptance
        
    - practice gratitude
    - When was the last time you did absolutely nothing ?
    - surround yourself with people who are better than you
    1. .Begin every day by getting your first thought, first emotion, and first action right.
    2. End your day with introspection by asking yourself the question:
        
        “Where did I improve today?"
        
    3. Write down 11 aspects you’ve learned in this Quest and you’re going to practice on a consistent basis.