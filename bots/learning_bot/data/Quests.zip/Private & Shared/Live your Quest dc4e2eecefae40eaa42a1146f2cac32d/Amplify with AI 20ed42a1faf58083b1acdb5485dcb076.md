# Amplify with AI

# 🚀 The Quest in 3 Sentences

1. 

# 🎨 What do I use from this Quest ?

## Who Should take this Quest?

# ☘️ How the Quest Changed Me

<aside>
💡 How my life / behaviour / thoughts / ideas have changed as a result of reading the book.

</aside>

- 

# ✍️ My Top 3 Learnings

- 

# 📒 Summary + Notes

- Week 1
    
    Ressources
    
    - AI find the most important individual articel for you, be more precise
    - AI is us deeply connected
    - AI helps you be more productive = work 4 days achieve more than people who work 6 days
    - AI is most about effective commuication and delegation
    - what is valuable for aI to know about me
    
    Actions
    
    - do the 3 MIQs = Experiences Growth and Contribution
    - Goalsetting
        - upload your goals in GPT, let. them transcribe
        - prompt to analyse my goals and advisor and improve my goals
        - create a vision board
        - Ai Can identify your blind spots
    - for prompting follow ACE framework
        - Action, single steps, Context background, Examples
    - Select a goal ⇒ take 5-10 pictures relate to goal ⇒ generate somehting with AI ⇒ song, visionboard and so on
        
        [Mindmaps_and_Custom_GPTs (1).pdf](Amplify%20with%20AI%2020ed42a1faf58083b1acdb5485dcb076/Mindmaps_and_Custom_GPTs_(1).pdf)
        
        ![image.png](Amplify%20with%20AI%2020ed42a1faf58083b1acdb5485dcb076/image.png)
        
        hooks ⇒ story
        
        ![image.png](Amplify%20with%20AI%2020ed42a1faf58083b1acdb5485dcb076/image%201.png)
        
        ![image.png](Amplify%20with%20AI%2020ed42a1faf58083b1acdb5485dcb076/image%202.png)
        
        what I want to do, What are experts doing ⇒ what am I doing ⇒ write it 
        
        ![image.png](Amplify%20with%20AI%2020ed42a1faf58083b1acdb5485dcb076/image%203.png)
        
        answer the questions
        
        ⇒ your personal story inject in ai email
        
        ![image.png](Amplify%20with%20AI%2020ed42a1faf58083b1acdb5485dcb076/image%204.png)
        
        rewrite the email with the writing style of this person 
        
- Week 2
    
    Ressources
    
    - create custom gpt, character builder 16*9
        
        [custom Gpts](Amplify%20with%20AI%2020ed42a1faf58083b1acdb5485dcb076/custom%20Gpts%20211d42a1faf58093813fd1a3788f0d0e.md)
        
    - AI for learning take a podcast
        - “Can you please create a powerful summary of this episode, highlighting key points and amazing nuggets of wisdom?”
        - From the summary, pick one concept (e.g., “GAAU”) and prompt:
            
            “Expand on concept seven.”
            
        - Instruct the AI to Design a four-question multiple-choice quiz on your idea.
        - Enable ChatGPT’s memory feature, then ask:
            
            “What do I really need to know from this content? Be brutally honest, based on everything you know about me—my goals and blind spots.”
            
    - create your ai teammebers
    - RAIN ⇒ RAPID AI input ⇒ 123 ⇒ tap talk transform ⇒ go and structure your messy thoughts with GPT
    - work more with TASKS
        - Context Actions requirements
        - Personalization, assets what role, Approach to take ( want to open the message)
        - daily set your one goal
        
        ![image.png](Amplify%20with%20AI%2020ed42a1faf58083b1acdb5485dcb076/image%205.png)
        
    - **G**rinding (repetitive) tasks
    - **A**voidable (dreaded)
    - **I**ntensive (time-consuming)
    - **N**eglected (valuable but deferred)
    
    Actions
    
    - generate custom GPT agents on my personal jarvis for my personal topics, health, and so on business
    - use gpt as a cooking chef and meal analyser, make fotos of what you eat and have
    - plan your vacation with GPT
    - create virtual gpt experts
        - **Curate Resources**: In ChatGPT, ask *“List the top 10 books on webinar scripting and sales presentations.”*
        
        > Deep Research: Copy that list, click “Deep Research,” prompt:
        > 
        > 
        > *Create a master guide on webinar scripting using these sources.*
        > 
        - Answer the clarifying questions (audience, outcomes, format).
        - **Download Data**: When research completes, download the guide as a plain-text file.
        - **Create Custom GPT**:
            1. In ChatGPT, go to “Explore GPTs” → “Create.”
            2. Name it (“Webinar Specialist” or “Autoresponder Master”).
            3. Under Instructions, paste your system prompt (e.g., “Build me a master autoresponder GPT…”).
            4. Upload the plain-text research doc.
    - use gpt customer instructions
    - Identify 1-3 step workflows daily basis to automate with GPT
    - [https://airtable.com/appr9GnzenrH6FxJc/shrMeTYqZfc9DiN8c](https://airtable.com/appr9GnzenrH6FxJc/shrMeTYqZfc9DiN8c)
    - automate daily or timeconsuming tasks
- Week 3
    
    Ressources
    
    - Improve OKRs with AI
    - Be Bold stretch your goals, Learn and automate
    
    Actions
    
    - non negotiable learning time 2-3h a week  or daily 30min
    - automate many things with AI
    - ai let you connect dots

# 📒 Things I still apply

## 💪 My Journey

- Week 1
- Week 2
- Week 3