# Speak and inspire

Author: Lisa Nicols
Fiction?: Non-Fiction
Notes Status: Notes In Progress
Duration: 30
progress: 9

# 🚀 The Quest in 3 Sentences

1. 

# 🎨 What do I use from this Quest ?

## Who Should take this Quest?

# ☘️ How the Quest Changed Me

<aside>
💡 How my life / behaviour / thoughts / ideas have changed as a result of reading the book.

</aside>

- 

# ✍️ My Top 3 Learnings

- 

# 📒 Summary + Notes

- Week 1
    
    Ressources
    
    - most of us have never used our voice to its full impact
    - as a human being, speaking is the doorway to your greatest needs and desires manifesting
    - Speak your truth, speak that people listen, gain courage to speak in front of people
    - speak with intention
    - it is not about the words, it is how you deliver it
    - be authentic in your voice
    - the most important gift, is the gift of transparency, it is the most beautiful and the least given
    - you need to do it first then others will follow
    - storys conennect hearts
    - fear is just an emotion that informs you to gather more knowledge on a particular subject
    - fear is the future story
        - invite yourself to change this story
    
    Actions
    
    - What should your voice do ?
    - What do I want people to feel, think and do as a result of my voice ?
    - Feeling
    => feel heard, and worshiped, calm, relaxed, energized, inspired, courage, do more new things, take risk, live life, save,
    Thinking
    => nice listener, kind words, helpful person, new way, optimistic,
    Doing
    => what they love, with passion and Purpose, do new things, inspire for new things
    - find out what is important to them ⇒ build on that and inspire them
    - How Do I add value ?
    - be the best version of yourself in the moment
    - let me share the part of me I normaly wouldnt share, let me share the transparency, the vulnerability, my fears, my joy, my crappy mistakes, my issues, my greatness, my brughtness, my brilliance, my breakdown
    - find 25 incidents that can be a story
    - write down your legacy
        - Here lies a men who …
        - what do you leave ?
        - how do you inspire ?
        - how do you contribute ?
        - what do others say about you ?
        - What do you want to be remembered for that you havent done yet ?
- Week 2
- Week 3

# 📒 Things I still apply

## 💪 My Journey

- Week 1
- Week 2
- Week 3