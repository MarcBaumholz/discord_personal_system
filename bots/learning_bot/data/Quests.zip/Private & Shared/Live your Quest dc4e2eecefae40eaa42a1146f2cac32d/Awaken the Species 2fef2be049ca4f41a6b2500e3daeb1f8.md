# Awaken the Species

Fiction?: Non-Fiction
Notes Status: notes in review

# 🚀 The Book in 3 Sentences

1. the purpose of life is to recreate yourself anew in the next golden moment of now, in the next grandest version of the greatest vison ever you held about who you are

# 🎨 Impressions

The 16 Behaviours

1. Sees the unity of all life and live into it
2. Tell the truth, always
3. Do what you say, always
4. Do what works
5. Self-regulate their behavior
6. Do not experience insufficiency
7. practice stewardship, not ownership
8. share everything with everyone, always
9. harmonize technology with nature
10. do not kill anyone
11. nurture your environment
12. never poisen yourself 
13. never compete
14. be clear that you need nothing
15. express and experience unconditional love to everyone
16. know how to harness the power of metaphysics

## How I Discovered It

## Who Should Read It?

# ☘️ How the Book Changed Me

<aside>
💡 How my life / behaviour / thoughts / ideas have changed as a result of reading the book.

</aside>

- 

# ✍️ My Top 3 Quotes

- 

# 📒 Summary + Notes

- Week 1 Unity & Truth
    
    Ressources
    
    - 98% of the worlds people are spending 98% of their time on things that do not matter
    - Tell the truth always, instead the power of Karma will happoen, there is no reason to lie
    - What am I being is my choice ⇒ I make the decision ⇒ transform shift from doing into being ⇒ Who would achieve this ? and be the person
    - Unity
        - an awakened species sees the unity of all life and lives into it. Humans in an unawakened state often deny it or ignore it ⇒ we are all one
    - Truth
        - Allow to think instead of tell them what to think
        - an awakened species tells the truth always. Humans in an unawakened state often lie, to themselves as well as to others
        - speak the truth but soothe your words with peace
    
    Actions
    
    - ask questions and you get answers
        - What does this task have to do with the agenda of my soul ?
    - Decide on a daily basis one word state of being
        - how do you want to be ? Calm, helpful, patient, compassionate
        
        ![Untitled](Awaken%20the%20Species%202fef2be049ca4f41a6b2500e3daeb1f8/Untitled.png)
        
    - have transperency as a lifestyle and speak openly in every moment to every person
        - tell the thruth to yourself about yourself
        - tell the truth to yourself about another
        - tell the truth about yourself to another
        - tell the truth about another to that other
        - tell the truth to everyone about everything
- Week 2 Do say & What works & justice & punishment
    
    Ressources
    
    - I could be right, I could be wrong, that is why you need to go within to see your soul resonates and harmonizes with the material
    - The say and do congruence
        - An awakened species says one thing and will do what they say. Humans in an unawakened state often say one thing and do another
        - Do what you say is great purpose
        - know what you say is great clarity
        - reliability is the foundation of all functional civilization
    - What works
        - there ius no such thong as right and wrong, only what works and what does not work, given what it is what we are trying to do
    - Justice is an action, not a reaction
    
    Actions
    
    - what you say every single time will be what you do without exception
    - Write down what worked and what didnt in the past and evaluate why
    - write down things you have done, which you have not been able to forgive yourself
- Week 3 Insufficiency & ownership & sharing & machines annd nature
    
    Ressources
    
    - Insufficiency
        - insufficiency is an illusion
        - you need nothing to be happy
    - Ownership
        - do we really need the right of owning something ?
        - the idea of ownership will be replaced by the concept of stewardship
        - it is not honorable if you win when another person lose ⇒ no one benefits unless everyone benefits
    - sharing
        - an awakened species shares everything with everyone all the time
        - A true leader is somebody who says: I will go first
    - Machines and Nature
        - dont confuse: Accomplishment with enrichment. Achievement with fulfilment. What we are doing with what we are being
        - An awakened species creates a balance between technology and cosmology; between machines and nature
    
    Actions
    
    - be the source in life, the act of giving something away of what you think you do not have enough and supply it to others who have less, you realize you have enough
    - looking arround and looking for people who have less than you and then giving that what you think you have less will give you all you need
    - distribute to others instead of gather new things
    - Do not become attached to the things you own, it is temporary, do not stick your happiness to the thing
    - What is the biggest thing you ever shared with anyone else ?
    - Ask yourself, is this natural ? look at the balance between nature and machines
- Week 4 Killing and death
    
    Ressources
    
    - awakened people do not kill
    - we are what we put into us, do not poisen yourself
    - All Emotions are chosen, emotions are not things that happen to us, emotions are things that happen through us
    - instead of win the point, win the heart
    - an awakened human know that he/she needs nothing to be happy
    - experience and express unconditional love for everyone
    - the purpose of relationships is never what we get out of it, it is what we put into it
    - purpose of love is to demonstrate that you are complete and to share your completion with others
    - every day in every way I am getting better and better
    - feelings are the language of the soul
    - what you resist persist
    - understanding replaces forgiveness
        - understanding others and you never need to forgive them
    
    Actions
    
    - inspire others by be inspired
    - do not compete, co elevate cooperate
    - Nobody wins unless everybody wins ⇒ like a relatinship
    - I am enough
    - move through ligr with a specific purpose in every moment
        - I find, I create, I will and I am …
    - When negative thoughts come up ⇒ accept them and let them pass
    - watch what and how you are thinking
    - life is not about you, it is about everyone whose life you touch and the way in which you touch it

# 📒 Things I still apply

## 💪 My Journey

- Week 1
- Week 2
- Week 3

![Untitled](Awaken%20the%20Species%202fef2be049ca4f41a6b2500e3daeb1f8/Untitled%201.png)