# The Stage Effekt

# 🚀 The Quest in 3 Sentences

1. 

# 🎨 What do I use from this Quest ?

## Who Should take this Quest?

# ☘️ How the Quest Changed Me

<aside>
💡 How my life / behaviour / thoughts / ideas have changed as a result of reading the book.

</aside>

- 

# ✍️ My Top 3 Learnings

- 

# 📒 Summary + Notes

Week 1

- Day 1  Primary message
    
    R:
    
    - overcome your concerns
    - take risk to share your story
    - play fully
    - if you dont have the passion, so many obstacles will get in the way
    
    A:
    
    - test things with others
    - What is your primary message
    - prioritize your topics
        - my topic is AI for healthy work, get more done and take care of yourself.
        - Use AI for selfcare ⇒ automate things to focus on what is important and to keep balance in life
    
    Day 2 Target Audience
    
    R
    
    - What is most important to them ?
        - their career
    - How are you going to help them the most ?
        - deal with new tech ⇒ increase their productivity and life satisfaction
    - What is your presentation going to do for them ?
        - It generates awareness and helps to implement routines to take care of themselfes
    - Why do you feel compelled to reach them ?
        - because I am the same, and I learned how important it is to take care of yourself
    
    A
    
    - Who do you wanna impact ?
        - stressed people who do not have the time to take care of themselves, that I can do it, because I love it.
    - create an Avatar
        - young 20-25
        - tech interested but maybe study BWL
        - the benefit is to get rid of overwhealm, they have someone they can talk to and they know they do not need to do it by their own
    
    Day 3 inspiringg impact statement and day 4 message
    
    R
    
    - impact on the world
    - have emotional connection to your impact
    - impact
        
        ![Untitled](The%20Stage%20Effekt%20ac841265923e4777abba625ad1ca3cce/chrome_feATmTqUGQ.png)
        
        ![Untitled](The%20Stage%20Effekt%20ac841265923e4777abba625ad1ca3cce/Untitled.png)
        
    - first understand what is in it for you, take care of yourself, and make sure your needs are getting met
    - 
    
    A
    
    - I want to revolutionice education and life, because life is different nowadays, we need to change and adjust
    - What is in it for you ?
        - to see that what I do make sense and helps also others, to live my life doing what I love, see the joy of others when i share my thoughts
        - To share what I love is the best way
    
    Day 5 Lead the Road to Success with Strategic Outcomes
    
    R:
    
    - first you design your talk
    - the more personal touch, the better the personal experience
    - secondary objectives help you select better stories
    - 
    
    A:
    
    - identify primary and secondary objectives
    - Brainstorm a list of every possible positive outcome that could happen as a result of your sharing your message with the world.
- part 2 Stories
    
    Day 6 The evolution of storytelling A journey through time
    
    R:
    
    - pitching is all about storytelling, our brains love stories,
    - cataloging your stories
    - do not write your story out
    - Stories have rythm, pattern and certainty and predictability
    - if you can dedscribe the nature of somebodys problem better than they can, they will automatically assume that you are in posession of the solution
    - be vulnerable and authentic about who you where before you overcome the challenge
    
    A:
    
    - create a story journal
        
        give them a title. record bullet points, tag with topics, tiem esimate to deliver story
        
    - write down your first 10 stories
        
        [Story_Journal_Template_Editable.pdf](The%20Stage%20Effekt%20ac841265923e4777abba625ad1ca3cce/Story_Journal_Template_Editable.pdf)
        
    - my stories
        1. START founding story
        2. my work experience story, good startup, insolvency startup, wring ways swiss life
        3. Self help journey ⇒ wim hof and 1 book a week ⇒ mindvalley ambassador
        4. organise RTSS event 250 people
        5. started with personal dev ⇒ jim kwik bodo schäfter ⇒ online course 
        6. hackathon experiences over the years 22,23,24, local ones 
        7. START nearly gone story, wrong leadership ⇒ high fluctuation
        8. Monestary story half year monestary 
        9. semester abroad malta learnings 
        10. Starting my own website ⇒ progress idea and so on 
        11. Tinder hero story 
    - The heros journey
        - main character
        - challenge
            - tell how ward it was and the difficulty and the strive you went through, other will feel resonance
        - overcoming challenge
            - approach that story
        - evolution of the hero
            - grew out of that story
            
    
    Day 7  Explore types of stories for versatile storytelling
    
    R:
    
    - The origin Story ⇒ share the origination of the Idea ⇒ involve them in the origination, gives a sence of ownership, showcase dedication and simplify complex concepts  ⇒ feel like you know them  ⇒ why I do this
    - The more you know about someones story, the more you want to follow them
    - An Origin story exposes the honesty and the authenticity of why you do what you do
    - create behavior change dynamics ⇒ not giving set of rules
    - Oncec you begin to understand the authenticity of the origin story, you become quite intrigued by the prospect of actually moving forward
    - An Investment story is a story of you accumulating the skills or the resources that you have to do what it is that you do for the world  ⇒ the work that got in to figure out how to make this product ⇒ why I have the knowledge to teach you this right now ⇒ journey I wen through
    - remember how painfull my live was when i wasnt putting my message out
    - The methaporical /allegoriical / Parallel Story ⇒ teach a complex concept in a easy way ⇒ similar pattern with metaphors
    
    Actions:
    
    - Write the story down in your story journal immediately , the minute it pops into your head
    - Find your Origin storys for big topics of your life
        - Origin of START
        - Origin of Find optimal career, study
    - investment story ⇒ how you aquired your skills
        - leadership, to halfe way go insolvency
        - Event organise ⇒ RTSS get thrown into ⇒ and gain network ⇒ research talk with people
        - Pitching ⇒ go out and do it, get challenged ⇒ take programs E2C, TTI, ESE, Startplan
        - Coding ⇒ get itno work and real coding projects to learn
    
    Day 8
    
    R:
    
    - your live experiences are infinitely valueable for other people
    - Each and every one of you in the audience has stories and life experiences that would be entertaining and valuable for me to hear if I was the on in the audience
    - you entertain a deeper conversatoin with yourself to find these rembrandts
    - there is a time before we recognized the value of our stories
    - our stories show up as inventory
    - 
    
    A:
    
    - look for your own rembrands ⇒ make this with people who know you
        - your unique skills with higher value
        - Rembrandts:
            - startup ecosystem contacts
            - Personal growth books and courses
            - AI Development Data science knowledge
            - Best conferences and HAckathons in EU experiences
            - Power of showing up and going out of your comfort zone
- Part 3
    
    Day 11 
    
    R:
    
    - never write your speech out, yo break authenticity by writing it out
    - humans would rather be with an authentic enemy than an inauthentic friend
    - dont take notes up on stage with you
    - do not need slides  ⇒ slides are for evidence or emotions ⇒ they shouldnt be for data
    - dont say the audience the time left
    - speech map ⇒ better memory ⇒ flexibility
    - speech map
        - topic middle
        - clocwise the topics with bullet points
        - have small stories to each point
        - every story can be told short or long
    - Impact per minute
        - impacts per minute refer to the number of times you impact your audience
            - impact with positive, negative, or cognitive response feelings
        - How many impacts per minute
            - ipm of 0,5 or 1 ⇒ definately good
            - ipm of 3-7 mainstream media
        - 
    
    A:
    
    - organise by speech map (mindmap)
    - tell a story to tell a point
    - tell a point with a story
    - watch the videos ⇒ and write down the Impact moments
    
    Ken robinson
    
    1 pos stories, 2 talent everybody , 3 min intro pain and positive points 
    
    3 another story ,4 innovation is possible kids are amazing , go with childs mind, 4 min another story , 5 being wrong story ⇒ message adults lost capacity, 6 educte out of creativity, 7 story of son education system are always similar, 8 mind experiement story reflect educate , 9 what you are good isnt valued in school, 10 intelligence is diverse, dynamic, distinct, 11 how do people discover their talent, 12 story of a child to discover their passion, 13 job make something of it 
    
    eric
    
    1. hindside window, 2 point about window, 1min story father, 3 resentment in the past equals fear in the future, 4 gratitude in past faith in futre, 5 clean up our past, 6 story with books and drama 7 anybody here from england 9 story of the guy next to him, some jokes 10, 4 min many information value, 11 story about roadhacks , 12 another story about traffic referee , 13 story of letting go, 14 life hacked roadrage, 15 figure out a habit and break it, 16 story emotional mother daughter , 17 it is never to late to have a childhood , 18 clean future clean past, 19 now handle present, always ask who knows him, who where there and hold your arm, 20 story travel in present what does help, 21 story where they down and what would help, walk through the pain in present, bring them in your process of thinking why might I …. , what is now the best way ? 22 guide by questions, 23 everything is gonna be okay 24 story of losing it all, valley story, and going out of valley, 25 when you are rational people listen to you, when you are anger not, 26 clear guidance in the end as last sentences  
    
    [Speech_Map_Template_.pdf](The%20Stage%20Effekt%20ac841265923e4777abba625ad1ca3cce/Speech_Map_Template_.pdf)
    
    Day 12
    
    R:
    
    - Beginning and the end is important
    - F15 ⇒ use many gas to launch as in the air
        - beginning of presentaion getting it tight a fantastic way to start gaining momentum
        - you have first an Icebreaker (maybe you think, must be nervous to stand here on stage, but the ones who should be nervous are you, imagine I am standing here and just steling 1h of your life. You should be nervous I am about to take 2 h of your life and it could be horrible, it could be terrible! you have no Idea )
        - local events, comics, laughing, jokes
    - Once the audience laughs they relax and the ice is broken ⇒ it requires Risk
    - say something about local events, yesterday I was here at this event, tomorrow I am preparing to go to this event here in the region
    - After Icebreaker Introduce yourself, do not do it, have the MC introduce yourself
        - write out a script of introduction ⇒ let a friend, a fan, another spaker write this intro
        - let others introduce yourself ⇒ if not make it short by yourself wth a story
    - the big fatclaim is another point
        - put them at ease
        - make the autdiencec a promise that their time is well invested
            - be focused
            - I am really really excited to share this specific information with you, because I believe this is a talk that many of you will remmeber for years to come
            - Do not make a promise if you could not hold it
        - make a üromise because it settles the audience down and makes them feel good and encourage you to step up to the promise
    - L15 ⇒ how you land  end the talk
        - never go over time
        - never ask for more time
        - 5min sign 3 min prep 2 min ending
        - know how to end befor you begin (with a solid point or call to action)
            - poignent story, quote
            - And with that , what I would like to finish with is a quote from maryanne williamson  “ Our deepest fear is not that we are inadequate , it is that we are in fact powerful beyond measure
            - call to action ⇒ interact ⇒And now, now that we have come to the end , What I want you o do is meet me at the back table ⇒ show there ⇒ and that is where I will be ti answer all your questions
    - you get to do what you do because you have great people arround you
    
    A: 
    
    - create your F 15
        - icebreaker
    - create yout L 15
        - Quote, call to action, collaborate with other people
    - create your self introduction with others
    
    Day 13 Design your Point Map for Effective Communication 
    
    R:
    
    - A point map helps the audience learn certain things as a result of a particular presentation
    - decide your core point
    - decide What are the samall things people need to understand to get your core point
    - create a master list of those points
    - Order these points in logical order
    - populate the points into t he map without stories
    - The more points the more data and less emotion, the less emotion the less memory
        - better pick 6 points instead of 25 points
    - A well told story creates an emotional response and an emotional response stimulates action
    
    A:
    
    - Make your list of Important points
    - ASK: Which points are actually really Important ?
    
    Day 14 Anchor your ponts to ensure message resonance
    
    [Hindsight_Window_Speech_Map_Template.pdf](The%20Stage%20Effekt%20ac841265923e4777abba625ad1ca3cce/Hindsight_Window_Speech_Map_Template.pdf)
    
    R:
    
    - sometimes sharing a perspective in story telling style helps to make it more memorable
    - What are the stories that tell the points in the best possible way ?
    - Once you have a speech map, you have the ability to deliver a single talk 10 different times in 10 different ways
    - 1 way announce the point and then tell the sroy
    - 2 way allow the audience to arrive at teh point by their own
    
    A:
    
    - overlay your own storys on erics map
    - populate the map with different stories
    - Identify story that can bestly communicate that point
- Maps
    
    ![Untitled](The%20Stage%20Effekt%20ac841265923e4777abba625ad1ca3cce/Untitled%201.png)
    
    ![Untitled](The%20Stage%20Effekt%20ac841265923e4777abba625ad1ca3cce/Untitled%202.png)
    
    ![Untitled](The%20Stage%20Effekt%20ac841265923e4777abba625ad1ca3cce/Untitled%203.png)
    
    ![Untitled](The%20Stage%20Effekt%20ac841265923e4777abba625ad1ca3cce/Untitled%204.png)
    
- Part 4
    
    Day 16 
    
    R:
    
    - be calm comfortable and confident
    - fear of public speaking is one of the most in the world
    - authentic people are the best
    - nervousness is an inauthentic plea for sympathy
        - dont communicate that you are nervous
    - nervousness and excitement are exact the same emotions with one subtle difference, your expectation of the outcome
    - regulate your breathing, take deep breaths
    - use your eyes ⇒ focus stressed or so cortisol release
    - eyes relaxed ⇒ do not stare ⇒ look at the whole room ⇒
    
    A:
    
    - sleep good nutritioin
    - meditate and visualize your speech
    - breath deeply
    - look sparsly at the whole room
    - walk on the stage ⇒ hear motivational music before
    - develop your stage prep routine
    
    Day 17 Use authenticity and attraction to captivate your audiance
    
    R:
    
    - you cant fuel the audiance by playing authentic
    - overdeliver ⇒ then they will give back to you
    - you do not need to be perfect, you just be you and share with vulnerability
    - it helps to deliver your message as if the audiance are children
    - We want borad spectrum appeal ⇒ get your title attract to your story ⇒ create a higher level of appeal for a particular audience
    - people like storys to tell storys ⇒ powerful funny interesting
    - 3 levels
        - 1 soft quite deliberate slower ⇒ kinesthetic
        - 2 listen sound centric and auditory ⇒ auditoory
        - 3 visual picture words ⇒ imagine  Y ⇒ visual
    - To deliver effectively in an engaging way you need to become trilingual
    - long pauses for powerful points
    - The chraisma pattern ⇒ speaks to how you put the visual auditory kinesthetic communication together
    - build it up with the charisma pattern
    
    A:
    
    - tell a story to people as if the audiancec would be children
    - Deliver a story with all 3 vocal tones
    - take a couple of breaths before you start
        - start kinesthetically breath and then warm the presentation up auditorily and take it up to a visual range
    
    Day 20 Move beyond words for effective communication
    
    R:
    
    - It is not okay to walk out and acknowledge your nervousness
    - put the right image out there for the audiance when you walk on stage
    - Your tone of voice and physiology are equally important
    - Use your hands more deliberately
    - uncertainty
        
        ![Untitled](The%20Stage%20Effekt%20ac841265923e4777abba625ad1ca3cce/Untitled%205.png)
        
        calm sensation 
        
        ![Untitled](The%20Stage%20Effekt%20ac841265923e4777abba625ad1ca3cce/Untitled%206.png)
        
        tell storys with good miming and hand gestures ⇒ use them in a more natural way
        
    - You are one talk away from incredible influence and the attraction of phenomenal opportunities
    - do not adapt your style ⇒ adapt your contetn for the audiance
    - constant improve your speaks
    - record every talk you do ⇒ [otter.ai](http://otter.ai) ⇒ transcirbe talk
    - DO not steal stagetime
    - never remind how much time or technical problems are
    - beleif in something bigger that you beliefe rightnow
    - let go of impossible ⇒ low beliefs are little viruses
    - put a message out in the universe and see for signs from the universe to take them
    - discomfort is where the growth is comming from
    
    A:
    
    - Go out and practice and regullary use it
    - if something goes wrong and need time ⇒ hey everybody turn to the right and tell their neigbour why you are here and what you expect from this event ⇒ then fix microphone
    - learn recall and then share your insights ⇒ teach to others
    - beleif in something bigger that you beliefe rightnow
- Mystories
    
    Marc Stories. Bode Schäfer Story Dirk Kreuter vetriebsoffensice und Legion lovelock, Story Schule nicht gelesen und dann mindvaööey jim Kwik Kurs, Story Speak and inspiriert Kurs, oderlifebook Wildheit Kurs, Krebs Story jedes Jahr einen, Story Shaolin Temple Buddhist, 90% Same, marcs laws jeden eine Story und marcs Website aufbauen