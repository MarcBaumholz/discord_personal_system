# Be extraordinary

Author: Vishen lakhiani
Fiction?: Non-Fiction
Genres: Business, Creativity, Life Advice, Productivity, meditation
Rating: 5-Star
Date Finished: August 19, 2020
Notes Status: notes in review
Duration: 30 days

# 🚀 The Quest in 3 Sentences

1. growth is the single most important thing in life

# 🎨 What do I use from this Quest ?

## Who Should take this Quest?

# ☘️ How the Quest Changed Me

<aside>
💡 How my life / behaviour / thoughts / ideas have changed as a result of reading the book.

</aside>

- 

# ✍️ My Top 3 Learnings

- Yoda: The fear of loss is the path to the dark side, train yourself to let go of everything you fear to lose
- grow so fast that the friends who have not kept in touch with you for 30days, have to get to know you all over again

# 📒 Summary + Notes

- Week 1
    
    Ressources
    
    - the 4 Levels of consciousness
        1. Victim state = live happens to you
        2. The Awakening = you have control and change things, intention
        3. Record your inner world (Intuition) = transcendence, forgiveness, gratitude, manifestation, creativity, visualization, affirmation
        4. Becoming Extraordinary = change/improve the world, compassion in life, guided inner voice, goals come from your heart
    - thoughts create reality, direct your brain on what to docus
    - Focus on transformation instead of learning
        - transform is a perspective shift, lifelessons
        - lerning is for the moment, forget 80% in 48h
    - you can transform through suffering/pain (Kensho) or through insight(Satori) Personal growt leads to more satori
    - Bending Reality = mental state of the mind, pulled by big goals and happy in the now, you have the universe behind you
    - compare yourself with your past self and be grateful for the development you made
    
    Actions
    
    - Segment intending (Meditation)
        - direct your thoughts tiwards what you want to do/have/feel
    - write down times in your life where you experienced the level 4 state
    - How big is your ROSE rate of selve evolution = grow every day
    - practice happiness in the now without your ego
    
- Week 2
    
    Ressources
    
    - Happiness
        - from Experiences
        - from Growth
        - from Meaning
    - Goals
        - do not set mean goals, if then goals, I get ..., so I can do ... FALSE
        - set end goals, follow your hearth, feeling and listen to inner self, th act of doing fills you with joy RIGHT
    - BRULES = Bullshit rules of the society and status quo
    - growth is the single most important thing in life
    - get a mission, not a career
    - words have only the meaning we give them
    - Unfuckwithable = when you are truly at peace and in touch wiith yourself, nothing  anyone says or does bothers you and no negativity can touch you
    
    Actions
    
    - practice gratitude on a daily basis
    - Write down your 3 MIQs = 3 most important questions  ⇒ have a balance between your goals
        - What experiences you want to have ?
        - How you want to grow ?
        - What do you want to contribute ?
    - write down self fuelled goals ⇒ goals which you can achieve even if you had nothing
        - grow and learn every day
        - be open minded
        - help people with small things, be kind
        - be grateful for what you have
    - Question your BRULES
        - make a list of all things you think are true
        - ask, was it your own thought, or from somebody else ?
        - create a own rule set and kill all bullshit rules in your life
- Week 3
    
    Ressources
    
    - I am enough
    - think what could be and dream big, 50% of your goals need to have a 50% chance of failure
    - Use meditation for your goals, for gratitude, to plan your day, to ask questions
    - intutition is your compass 5 Types
        - warning system
        - Inspiration
        - Connection
        - Support
        - higher purpose
    
    Actions
    
    - eye gazing
        - look in the mirror
        - focus on one eye
        - say I love you
        - repeat 10 times
    - What are your Kensho moments ?
        - turn problems into projects
    - Meditate
        - alpha trigger 3-2-1 ⇒ visualize number 3 3 times in your head, then number 2 3 times then number 1 3 times
        - Head to Toe deepening ⇒ relax every body part step by step
        - 10 to 1 countdown ⇒ count downwards and relax
    - Meditation techniques
        - Clearing out thhe garbage
            - ask questions
        - Quantum jumping
            - see future self and ask him/her questions
- Week 4
    
    Ressources
    
    - when you know what you want, take immediate action
    - evaluate people by theit size of their hearth
    - if you want to change the world, you need to be on your best in your darkest moments
    - the world gives you what you are
        - take the identity of an athlet or an CEO
    - for habits do not focus on the outcome, focus on what kind of person would achieve this and take the identity
    - have Vision and happiness in the now
    - 5 Laws of programming
        - forgive yourself for the past
        - respect the golden rule, do it for yourself not for others
        - Feel and think of others benefittiing from it
        - It must be the best for everyone concerned
        - It needs to be possible, you need to beliefe it
    
    Actions
    
    - Meditation Technique
        - Boardroom Techhnique
            - 5 Role models, people you respect and would love to take advice
            - ask them the questions and reply as you where those people
        - Mind body healing
            - visualize the pain and where it is
            - see yourself in perfect health with a healed pain
        - Practice creative Visualization
            - screen 15% above your eyeside and visualize what you want
        - Merging technique
            - practice the alpha triggers(3to1,10to1, head to toe)
            - see the screen 15% above your eyeside
            - see energy and in front of your closed eye see dark spots, fill them with your hand and imagine the energy can speak to you
            - listen to 3 words and 3 sentences that apear in your mind
            - then share 3 thoughts on what you want
            - listen deeply
    - practice Identity shift when applying new habits
        - Who would achieve this ?
        

# 📒 Things I still apply

Methods

- Segment intending
- gratitude practice
- clearing the garbage technique
- alpha triggers
- eye gazing
- quantum jumping
- boardroom
- creative visualization
- merging technique
- healing technique

Learnings

## 💪 My Journey

- Week 1
- Week 2
- Week 3