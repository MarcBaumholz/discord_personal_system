# Quest

# 🚀 The Quest in 3 Sentences

1. 

# 🎨 What do I use from this Quest ?

## Who Should take this Quest?

# ☘️ How the Quest Changed Me

<aside>
💡 How my life / behaviour / thoughts / ideas have changed as a result of reading the book.

</aside>

- 

# ✍️ My Top 3 Learnings

- 

# 📒 Summary + Notes

- Week 1
    
    Ressources
    
    - 
    
    Actions
    
    - 
- Week 2
    
    Ressources
    
    - 
    
    Actions
    
    - 
- Week 3
    
    Ressources
    
    - 
    
    Actions
    
    - 

# 📒 Things I still apply

## 💪 My Journey

- Week 1
- Week 2
- Week 3