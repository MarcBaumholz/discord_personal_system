# Uncompromised Life

Fiction?: Non-Fiction
Notes Status: notes in review

# 🚀 The Book in 3 Sentences

1. 

# 🎨 Impressions

## How I Discovered It

## Who Should Read It?

# ☘️ How the Book Changed Me

<aside>
💡 How my life / behaviour / thoughts / ideas have changed as a result of reading the book.

</aside>

- 

# ✍️ My Top 3 Quotes

- 

# 📒 Summary + Notes

- Part 1
    
    Ressources
    
    - Passion is doing what you love ⇒ purpose comes from doing what you love and meaning comes from sharing it
    - Your Mind does What it thinks you want to do it
    - negativity let you lose energy and positive things gain strength7
    - first you make your veliefs and then your beliefs make you
        - the funny thing you can beliefe whatever you want
    - You only respond to 2 things
        - the picture you make
        - the words you say to yourself
    
    Actions
    
    - What words are you telling your mind ? ⇒ listen deeply
    - tell your mind positive and extraordinary things
    - use good affirmations and positive songs
    - I love doing X, I choose to do Y
    - Change your words and pictures you create in your mind
- Part 2
    
    Ressources
    
    - Your brain is wired to do what is familiar
    - believe in yourself, make self praise familiar
    - A major contributor, a major factor in depression is people who use harsh, hurtful, critical words to describe themselves make that unfamiliar, just do the opposite.
    - people who succeed do what they dont want to do to get to where they want to be
    - when you delay things too much it does not serve you
    
    Actions
    
    - What is familiar and unfamiliar in your life ?
    - What is unfamiliar, you want to haver familiar in your life ?
    - What is familiar, you want unfamiliar in your life ?
    - Do WHat you Hate first
- Part 3
    
    Ressouces
    
    - eat mindfully and slow, look after yourself every day, recharge your battery daily
    - the actions you make make you
    - first you do X then you get the reward Y
    - do not let others set you down
    - negative feedback
        - say thank you for sharing that, oh I missed that can you say it again ?
    
    Actions
    
    - Take daily actions every single day in the direction of your goal
    - commit yourself to do something every single day
    - practice daily Gratification
    - practice daily Gratitude for who you are and what you have
    - I am Enough ⇒ say it every day ⇒ put it everywhere