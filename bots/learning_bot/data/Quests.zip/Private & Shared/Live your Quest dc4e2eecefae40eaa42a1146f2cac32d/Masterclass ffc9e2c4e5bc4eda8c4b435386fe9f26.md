# Masterclass

Fiction?: Non-Fiction
Notes Status: Published

# 🚀 The Book in 3 Sentences

1. 

# 🎨 Impressions

## How I Discovered It

## Who Should Read It?

# ☘️ How the Book Changed Me

<aside>
💡 How my life / behaviour / thoughts / ideas have changed as a result of reading the book.

</aside>

- 

# ✍️ My Top 3 Quotes

- 

# 📒 Summary + Notes

- Brain Course
    
    R:
    
    - biggest thread is stress and anxiety
    
    A:
    
    - Drink enough water in morining, helps to prevent fatigue in afternoon

Food

**Roast the cauliflower**

**1.** Set an oven rack 10 inches or so from the broiler. Preheat the oven to 375°F.

**2.** Trim the base of the cauliflower so it can sit flat. Flip the cauliflower base-side up and cut a deep “X” into the base, stopping when you reach the stems or the florets. This helps the core and base cook at the same rate as the rest of the head.

**3.** Rub the cauliflower all over with the olive oil, then season the cauliflower all over with the salt. Set the cauliflower in a large, heavy ovenproof skillet (11- to 13-inch works best). Transfer the skillet to the oven and roast to soften up the cauliflower (it’ll go from white to cream in color), 30 to 35 minutes. Pour ½ cup of water directly into the skillet and keep roasting until the water has evaporated and the cauliflower has patches of light golden brown and is just tender enough to easily be pierced with the tip of a sharp knife, 20 to 25 minutes more.

**Make the jerk sauce**

**1.** While the cauliflower is roasting, combine the sauce ingredients, including the finely grated zest and the juice of the lime, in a blender and blend on high speed until completely smooth, about 1 minute.

**Make the dish**

**1.** When the cauliflower is tender, remove it from the oven and heat the broiler. Use a flexible spatula to rub the top and sides of the cauliflower (don’t neglect those lower sides!) with the blended mixture.

**2.** Broil the cauliflower—basting it after 5 minutes with the juices that have accumulated in the skillet and trying your best to get that flavorful liquid in all its nooks and crannies—until the top has spots of black char, 10 to 12 minutes. Serve hot or warm.

### **Jerk Cauliflower**

3-4

**IngredientsInstructions**

---

**For the cauliflower**

- 1 large head cauliflower (about 3 pounds), leaves removed
- 3 tbsp extra-virgin olive oil
- 1 tbsp kosher salt

**For the jerk sauce**

- ¼ cup avocado oil
- ¼ cup coconut aminos
- 2 tbsp brown sugar
- 1 tbsp fresh thyme leaves, or ½ tbsp dried
- ½ tsp black peppercorns
- ½ tsp allspice berries
- 2 dried or fresh bay leaves
- 1 moderately spicy fresh red chile, such as Fresno, stemmed
- 1 scallion, trimmed and roughly chopped
- 1 large garlic clove, peeled
- 1 small shallot, roughly chopped
- ½ Scotch bonnet or habanero chile, stemmed
- 1-inch knob ginger, peeled and thinly sliced against the grain
- ¼ whole nutmeg, grated, or ⅛ tsp ground nutmeg
- 1 tbsp kosher salt
- Zest and juice of 1 lime

Money

spend less, invest more, earn more 

cannot track it cannot optimise it 

write down all money income and spendings

own more assets 

look where you can cut back 

wealthy people make money, invest and then spend 

minimum in each container ⇒ just increase the scale with life 

have some emergency money, have your money container, 

save money for emegency, big purchase or investment

⇒ do it strategically 

15% to investment 75 spend 10 % save 75 15 10 plan  ⇒ work towards 50 30 20 plan

invest

stocks, own business ⇒ crypto ⇒ real estate ⇒ gold 

80 % passive incestment, 15 % risk 5 % safe gold  ⇒ risk is startup investment and crypto 

nalyse for company

is there comteition ⇒  is the company really worth the stock market ? 

how safe or potential is the market 

ETFs

- invest in funds to diversify across basket of stocks
- invest passively automated regularly
- Index funds ⇒ passively ⇒ less fees ⇒ once a day ⇒ minimal money
- ETF ⇒ hybrid pas and active ⇒ as many times a day ⇒ no minimum
- mutual funds ⇒ actively managed ⇒ higher fees ⇒ once a day

invest in fund ⇒ can they withstand the lost of capital 

- who created the fund ?
- What is inside the fund ?
- How much is the fund costing me ?

Vanguard, charles schwab Fund 

- Total stock market, S&P 500, Healthcare, AI, tech, International stocks
- How much money is in this fund ?
- In what topics you want to invest
- ETFS 1 mrd. invested at least in etf
- under 100 million is bad in assets ⇒risky
- Asset allocation ⇒ how is this fund distributed ⇒ in which companies are invested and how much
- Expense ratio of the fund ? ⇒ each year pay for the fund
- VTI ETF to invest  ⇒ good fee 0,03 ratio
- CDAA ⇒ what Companies, How many Dollars and Asset Allocation